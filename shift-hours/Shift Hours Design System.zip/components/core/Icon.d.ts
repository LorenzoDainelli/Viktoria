import type { CSSProperties } from 'react';

export type IconName =
  | 'history' | 'settings' | 'close'
  | 'chevronRight' | 'chevronLeft' | 'chevronDown'
  | 'check' | 'download';

export interface IconProps {
  /** Glifo da mostrare. Solo i nomi del set dell'app. */
  name: IconName;
  /** Lato in px. 18 dentro le righe, 20–21 nelle testate. */
  size?: number;
  /** Spessore del tratto. Default: quello con cui l'icona è disegnata nel repo. */
  strokeWidth?: number;
  style?: CSSProperties;
}

export function Icon(props: IconProps): JSX.Element | null;
