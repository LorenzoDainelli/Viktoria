import React from 'react';
import { Icon } from './Icon.jsx';

export function Toast({ children, leaving, icon = true }) {
  return (
    <div className={'sh-toast' + (leaving ? ' sh-toast--leaving' : '')}>
      {icon ? (
        <span className="sh-toast__icon">
          <Icon name="check" size={20} />
        </span>
      ) : null}
      {children}
    </div>
  );
}

export function Toasts({ children }) {
  return (
    <div className="sh-toasts" aria-live="polite">
      {children}
    </div>
  );
}
