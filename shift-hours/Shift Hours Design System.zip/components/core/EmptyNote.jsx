import React from 'react';

export function EmptyNote({ children }) {
  return <p className="sh-empty">{children}</p>;
}
