import React from 'react';

/* Il set di icone dell'app: gli stessi path dell'SVG inline in src/index.html.
   Nessuna icona nuova: se serve un glifo, si aggiunge qui copiandolo dal repo. */
const PATHS = {
  history: (
    <>
      <circle cx="12" cy="12" r="9" />
      <path d="M12 7.5V12l3 2" />
    </>
  ),
  settings: (
    <>
      <path d="M4 8.5h16M4 15.5h16" />
      <circle cx="15" cy="8.5" r="2.4" fill="currentColor" stroke="none" />
      <circle cx="9" cy="15.5" r="2.4" fill="currentColor" stroke="none" />
    </>
  ),
  close: <path d="M6 6l12 12M18 6L6 18" />,
  chevronRight: <path d="M9 5l7 7-7 7" />,
  chevronLeft: <path d="M15 5l-7 7 7 7" />,
  chevronDown: <path d="M6 9l6 6 6-6" />,
  check: <path d="M4 12.5l5 5L20 7" />,
  download: <path d="M12 4v11m0 0l-4.5-4.5M12 15l4.5-4.5M5 19.5h14" />,
};

const WEIGHT = { history: 2, settings: 2, chevronLeft: 3, chevronDown: 3 };

export function Icon({ name, size = 20, strokeWidth, style, ...rest }) {
  const glyph = PATHS[name];
  if (!glyph) return null;
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth={strokeWidth ?? WEIGHT[name] ?? 2.4}
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden="true"
      style={{ flex: 'none', display: 'block', ...style }}
      {...rest}
    >
      {glyph}
    </svg>
  );
}
