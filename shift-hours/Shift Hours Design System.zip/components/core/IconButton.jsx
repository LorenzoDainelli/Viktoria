import React from 'react';

export function IconButton({ label, plain, className = '', children, ...rest }) {
  return (
    <button
      type="button"
      aria-label={label}
      className={'sh-iconbtn' + (plain ? ' sh-iconbtn--plain' : '') + (className ? ' ' + className : '')}
      {...rest}
    >
      {children}
    </button>
  );
}
