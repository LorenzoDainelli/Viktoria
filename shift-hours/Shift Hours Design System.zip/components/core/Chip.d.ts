import type { ButtonHTMLAttributes, ReactNode } from 'react';

/** Scorciatoia di ritorno nella testata: compare solo quando si guarda una settimana passata. */
export interface ChipProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  children?: ReactNode;
}

export function Chip(props: ChipProps): JSX.Element;
