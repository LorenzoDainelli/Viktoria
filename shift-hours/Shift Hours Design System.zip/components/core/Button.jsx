import React from 'react';

const VARIANT = {
  primary: '',
  secondary: ' sh-btn--secondary',
  danger: ' sh-btn--danger',
  ghost: ' sh-btn--ghost',
};

export function Button({ variant = 'primary', disabled, className = '', children, ...rest }) {
  return (
    <button
      type="button"
      className={'sh-btn' + VARIANT[variant] + (className ? ' ' + className : '')}
      disabled={disabled}
      {...rest}
    >
      {children}
    </button>
  );
}
