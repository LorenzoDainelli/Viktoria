Conferma che non chiede niente: fondo `--sh-text`, testo bianco, spunta azzurra.

```jsx
<Toasts>
  <Toast>Copied</Toast>
  <Toast leaving>Week ending 9 August saved to history</Toast>
</Toasts>
```

`<Toasts>` è il contenitore fisso in basso (`pointer-events: none`). I testi sono frasi finite in inglese, senza punto finale.
