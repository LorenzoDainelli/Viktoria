import type { ReactNode } from 'react';

/** Riquadro centrato per una lista vuota (settimana senza giorni, storico vuoto). */
export interface EmptyNoteProps {
  children?: ReactNode;
}

export function EmptyNote(props: EmptyNoteProps): JSX.Element;
