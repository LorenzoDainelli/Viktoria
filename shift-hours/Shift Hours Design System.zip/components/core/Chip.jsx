import React from 'react';

export function Chip({ className = '', children, ...rest }) {
  return (
    <button type="button" className={'sh-chip' + (className ? ' ' + className : '')} {...rest}>
      {children}
    </button>
  );
}
