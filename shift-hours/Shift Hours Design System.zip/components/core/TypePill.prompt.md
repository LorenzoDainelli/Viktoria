Pillola trasparente sul blu del blocco riepilogo, apre il foglio di scelta del tipo di settimana.

```jsx
<TypePill name="Week" onClick={openTypes} />
```

Fondo `hsl(0 0% 100% / 0.16)`, 36px di altezza. Usarla **solo** dentro `<HeroSummary>`: fuori dal blu non ha contrasto.
