import type { ButtonHTMLAttributes } from 'react';

/** Selettore del tipo di settimana. Vive **dentro** il blocco riepilogo: non ruba una riga. */
export interface TypePillProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  /** Nome del tipo attivo, es. `Week`, `Weekend`, `☕ Mornings`. */
  name: string;
  /** Nasconde il caret quando esiste un solo tipo. */
  showCaret?: boolean;
}

export function TypePill(props: TypePillProps): JSX.Element;
