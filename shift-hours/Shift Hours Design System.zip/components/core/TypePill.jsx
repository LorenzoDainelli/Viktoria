import React from 'react';
import { Icon } from './Icon.jsx';

export function TypePill({ name, showCaret = true, ...rest }) {
  return (
    <button type="button" className="sh-typepill" {...rest}>
      <span>{name}</span>
      {showCaret ? <Icon name="chevronDown" size={14} /> : null}
    </button>
  );
}
