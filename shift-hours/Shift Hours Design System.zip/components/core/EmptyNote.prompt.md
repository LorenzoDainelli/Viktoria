Messaggio di lista vuota: fondo `--sh-surface`, testo spento, centrato.

```jsx
<EmptyNote>No hours yet this week.</EmptyNote>
```

Una frase, nessun pulsante dentro, nessuna spiegazione tecnica.
