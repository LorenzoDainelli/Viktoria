Il pulsante di Shift Hours: sempre a piena larghezza, pillola, 54px di altezza minima.

```jsx
<Button onClick={copy}>Copy summary</Button>
<Button variant="secondary">Download backup</Button>
<Button variant="danger">Clear week</Button>
<Button variant="ghost">Keep it</Button>
```

`primary` è l'azione della schermata e ce n'è **una sola** (`Copy summary` nella barra in basso). `danger` è riservato a eliminare: mai per confermare qualcosa che non distrugge. `disabled` usa `--sh-disabled-bg` e perde l'ombra.
