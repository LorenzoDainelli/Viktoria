import type { ButtonHTMLAttributes, ReactNode } from 'react';

/** Pulsante tondo 44×44 delle testate. L'etichetta è obbligatoria: dentro c'è solo un glifo. */
export interface IconButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  /** Testo per lo screen reader, in inglese come tutta l'app. */
  label: string;
  /** Senza riempimento: usato dentro le righe delle impostazioni. */
  plain?: boolean;
  children?: ReactNode;
}

export function IconButton(props: IconButtonProps): JSX.Element;
