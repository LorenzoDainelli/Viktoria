import type { ButtonHTMLAttributes } from 'react';

/**
 * Pulsante a piena larghezza dell'app: pillola, min-height 54px.
 */
export interface ButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  /** primary = blu (una sola azione per schermata). danger = solo per eliminare. */
  variant?: 'primary' | 'secondary' | 'danger' | 'ghost';
  disabled?: boolean;
}

export function Button(props: ButtonProps): JSX.Element;
