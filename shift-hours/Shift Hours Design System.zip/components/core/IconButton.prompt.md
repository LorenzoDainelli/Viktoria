Pulsante tondo da 44×44 (minimo iOS) per le azioni delle testate.

```jsx
<IconButton label="Settings"><Icon name="settings" size={21} /></IconButton>
<IconButton label="Delete" plain><Icon name="close" size={18} /></IconButton>
```

Riempimento `--sh-surface`, glifo `--sh-text-muted`; `plain` toglie il riempimento. Non ridurre mai sotto 44×44.
