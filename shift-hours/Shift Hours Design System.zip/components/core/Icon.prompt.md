Wrapper per l'unico set di icone di Shift Hours: tratto tondo, 24×24, `currentColor`.

```jsx
<IconButton label="History"><Icon name="history" size={21} /></IconButton>
```

Nomi disponibili: `history`, `settings`, `close`, `chevronRight`, `chevronLeft`, `chevronDown`, `check`, `download`. Non inventare glifi: l'app non ne ha altri. Il `+` dei giorni e i `−`/`+` della regolazione fine sono **testo**, non icone.
