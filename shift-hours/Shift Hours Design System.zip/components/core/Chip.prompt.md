Pillola compatta della testata. Nell'app ne esiste **una sola**: `This week`, che riporta dalla settimana passata a quella corrente.

```jsx
<Chip onClick={backToCurrent}><Icon name="chevronLeft" size={14} /> This week</Chip>
```

Nel foglio componenti `.sh-chip` non ha ancora regole proprie: eredita dai pulsanti della testata. È uno dei punti da rifinire nel redesign.
