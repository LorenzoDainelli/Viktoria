import type { ReactNode } from 'react';

/** Conferma non bloccante, scura, sopra la barra d'azione. Sparisce da sola. */
export interface ToastProps {
  children?: ReactNode;
  /** Stato d'uscita (opacità 0 + 10px in basso) prima della rimozione. */
  leaving?: boolean;
  /** Spunta a sinistra. Default true: tutti i toast dell'app confermano qualcosa. */
  icon?: boolean;
}

export interface ToastsProps {
  children?: ReactNode;
}

export function Toast(props: ToastProps): JSX.Element;
export function Toasts(props: ToastsProps): JSX.Element;
