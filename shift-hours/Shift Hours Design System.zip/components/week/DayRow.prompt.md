La riga-giorno, unità di misura della schermata settimana: altezza minima 60px, raggio 18px, superficie piena senza bordo.

```jsx
<DayList>
  <DayRow name="Monday" hours="8.30 hrs" times="8:00 – 16:30" onClear={clear} />
  <DayRow name="Tuesday" today onOpen={open} />
  <DayRow name="Wednesday" hours="6.15 hrs" open>
    <TimeRange start={480} end={855} />
  </DayRow>
</DayList>
```

La ✕ è posizionata **sopra** la riga, non dentro il pulsante: è un secondo bersaglio da 44px che non ruba il tocco all'apertura. Il giorno si apre in posto — non si cambia mai schermata, e cresce in altezza invece di scattare (`sh-day__reveal`): gli altri giorni si spostano di conseguenza.
