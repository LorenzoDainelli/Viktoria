import type { ReactNode } from 'react';

/** Testata della schermata settimana: occhiello maiuscoletto + data, azioni tonde a destra. */
export interface ScreenHeaderProps {
  /** Occhiello, es. `Week ending`. */
  eyebrow?: string;
  /** Titolo: la data di fine settimana, es. `16 August`. */
  title: ReactNode;
  /** `<Chip>` e `<IconButton>`. */
  actions?: ReactNode;
}

export function ScreenHeader(props: ScreenHeaderProps): JSX.Element;
