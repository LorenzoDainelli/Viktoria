Le tre righe della schermata principale: testata, corpo scorrevole, barra d'azione.

```jsx
<AppShell header={<ScreenHeader eyebrow="Week ending" title="16 August" actions={…} />}
          footer={<ActionBar><Button>Copy summary</Button></ActionBar>}>
  <HeroSummary … />
  <div className="sh-days">…</div>
</AppShell>
```

Larghezza massima 440px, centrata. Scorre **solo** il corpo: la barra in basso non si muove mai.
