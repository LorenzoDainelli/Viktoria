import type { ReactNode } from 'react';

/**
 * Telaio della schermata settimana: testata ferma, corpo che scorre, barra d'azione ferma.
 * `height: 100dvh` + `min-height: 0` sul corpo: senza queste due il pulsante
 * `Copy summary` finisce fuori schermo su iPhone. Non sostituirle con min-height.
 */
export interface AppShellProps {
  /** `<ScreenHeader>`. */
  header?: ReactNode;
  /** `<ActionBar>`. */
  footer?: ReactNode;
  children?: ReactNode;
}

export function AppShell(props: AppShellProps): JSX.Element;
