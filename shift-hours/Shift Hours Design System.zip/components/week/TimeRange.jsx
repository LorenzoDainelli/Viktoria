import React from 'react';

const STEP = 5;

function fmt(min) {
  const h = Math.floor(min / 60);
  const m = min % 60;
  return h + ':' + String(m).padStart(2, '0');
}

function duration(start, end) {
  const t = end - start;
  return Math.floor(t / 60) + '.' + String(t % 60).padStart(2, '0') + ' hrs';
}

export function TimeRange({
  start = 480, end = 855, min = 360, max = 1200, onChange, scaleStep = 120,
}) {
  const [range, setRange] = React.useState({ start, end });
  const trackRef = React.useRef(null);
  const span = max - min;
  const pct = (v) => ((v - min) / span) * 100;

  const commit = (next) => {
    setRange(next);
    if ((next.start !== range.start || next.end !== range.end) && navigator.vibrate) navigator.vibrate(6);
    if (onChange) onChange(next);
  };

  const drag = (which) => (e) => {
    e.preventDefault();
    const track = trackRef.current;
    const move = (ev) => {
      const box = track.getBoundingClientRect();
      const x = (ev.touches ? ev.touches[0].clientX : ev.clientX) - box.left;
      const raw = min + (Math.max(0, Math.min(1, x / box.width)) * span);
      const snapped = Math.round(raw / STEP) * STEP;
      commit(which === 'start'
        ? { start: Math.min(snapped, range.end - STEP), end: range.end }
        : { start: range.start, end: Math.max(snapped, range.start + STEP) });
    };
    const up = () => {
      window.removeEventListener('pointermove', move);
      window.removeEventListener('pointerup', up);
    };
    window.addEventListener('pointermove', move);
    window.addEventListener('pointerup', up);
  };

  const nudge = (which, delta) => () => commit(
    which === 'start'
      ? { start: Math.max(min, Math.min(range.start + delta, range.end - STEP)), end: range.end }
      : { start: range.start, end: Math.min(max, Math.max(range.end + delta, range.start + STEP)) }
  );

  const ticks = [];
  for (let v = min; v <= max; v += scaleStep) ticks.push(v);

  return (
    <div className="sh-range">
      <div className="sh-range__readout">
        {fmt(range.start)} <span className="sh-range__arrow">–</span> {fmt(range.end)}
      </div>
      <div className="sh-range__duration">{duration(range.start, range.end)}</div>
      <div className="sh-range__track" ref={trackRef}>
        <div className="sh-range__rail" />
        <div className="sh-range__fill" style={{ left: pct(range.start) + '%', width: (pct(range.end) - pct(range.start)) + '%' }} />
        <div className="sh-range__handle" style={{ left: pct(range.start) + '%' }} onPointerDown={drag('start')} />
        <div className="sh-range__handle" style={{ left: pct(range.end) + '%' }} onPointerDown={drag('end')} />
      </div>
      <div className="sh-range__scale">
        {ticks.map((v) => (
          <span key={v} style={{ left: pct(v).toFixed(2) + '%' }}>{Math.floor(v / 60)}</span>
        ))}
      </div>
      <NudgePair
        groups={[
          { label: 'Start', onMinus: nudge('start', -STEP), onPlus: nudge('start', STEP) },
          { label: 'End', onMinus: nudge('end', -STEP), onPlus: nudge('end', STEP) },
        ]}
      />
    </div>
  );
}

export function NudgePair({ groups }) {
  return (
    <div className="sh-nudges">
      {groups.map((g) => (
        <div className="sh-nudge" key={g.label}>
          <button className="sh-nudge__btn" type="button" aria-label={g.label + ' earlier'} onClick={g.onMinus}>−</button>
          <span className="sh-nudge__label">{g.label}</span>
          <button className="sh-nudge__btn" type="button" aria-label={g.label + ' later'} onClick={g.onPlus}>+</button>
        </div>
      ))}
    </div>
  );
}
