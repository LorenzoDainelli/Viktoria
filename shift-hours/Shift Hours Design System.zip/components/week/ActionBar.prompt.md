Barra d'azione fissa: ombra verso l'alto, safe area iOS rispettata in basso.

```jsx
<ActionBar><Button disabled={!hasHours}>Copy summary</Button></ActionBar>
```

Un pulsante solo. Deve essere visibile senza scorrere anche con la settimana piena — è la verifica finale del redesign.
