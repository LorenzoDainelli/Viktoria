import type { ReactNode } from 'react';

/**
 * Una riga-giorno della settimana. Vuota = grigia con un `+`; impostata = azzurra
 * con ore e orari; aperta = bianca in rilievo, con lo slider dentro.
 */
export interface DayRowProps {
  /** Nome del giorno in inglese, es. `Monday`. */
  name: string;
  /** Ore già formattate, es. `8.30 hrs`. Assente = giorno vuoto. */
  hours?: ReactNode;
  /** Intervallo, es. `8:00 – 16:30`. Nascosto quando la riga è aperta. */
  times?: ReactNode;
  /** Pallino blu del giorno corrente. */
  today?: boolean;
  /** Riga aperta: mostra `children` nel pannello interno. */
  open?: boolean;
  onOpen?: () => void;
  onClear?: () => void;
  clearLabel?: string;
  /** Contenuto del pannello aperto: sempre `<TimeRange>`. */
  children?: ReactNode;
}

export interface DayListProps {
  children?: ReactNode;
}

export function DayRow(props: DayRowProps): JSX.Element;
export function DayList(props: DayListProps): JSX.Element;
