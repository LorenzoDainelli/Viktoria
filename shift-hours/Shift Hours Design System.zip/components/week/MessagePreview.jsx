import React from 'react';

export function MessagePreview({ label = 'Message preview', text }) {
  return (
    <div className="sh-preview">
      <span className="sh-preview__label">{label}</span>
      <p className="sh-preview__bubble">{text}</p>
    </div>
  );
}
