import React from 'react';

const DAY_LABELS = ['M', 'T', 'W', 'T', 'F', 'S', 'S'];

export function HeroSummary({ label, total, unit = 'hrs', pay, payLabel = 'Estimated pay', typePill, week }) {
  return (
    <section className="sh-hero">
      <div className="sh-hero__top">
        <span className="sh-hero__label">{label}</span>
        {typePill}
      </div>
      <div className="sh-hero__grid">
        <div>
          <div className="sh-hero__total">
            {total} <span className="sh-hero__unit">{unit}</span>
          </div>
          {pay ? (
            <div className="sh-hero__meta">
              {payLabel} <span className="sh-hero__pay">{pay}</span>
            </div>
          ) : null}
        </div>
        {week ? (
          <div className="sh-hero__week">
            <div className="sh-hero__bars">
              {week.map((d, i) => (
                <i
                  key={i}
                  className={(d.on ? 'is-on ' : '') + (d.today ? 'is-today' : '')}
                  style={{ height: (d.on ? Math.max(14, d.pct ?? 60) : 12) + '%' }}
                />
              ))}
            </div>
            <div className="sh-hero__barday">
              {DAY_LABELS.map((l, i) => <span key={i}>{l}</span>)}
            </div>
          </div>
        ) : null}
      </div>
    </section>
  );
}
