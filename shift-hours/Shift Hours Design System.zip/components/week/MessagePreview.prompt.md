Quello che si legge è esattamente quello che si incollerà: nessun riassunto, nessuna formattazione aggiunta.

```jsx
<MessagePreview text={"Week ending 16 August\nMonday: 8:00 - 16:30 8.30 hrs\n31 hours and 40 minutes"} />
```

Angolo in basso a sinistra più piccolo (12px contro 24px): è la coda del fumetto. Il testo non si tronca mai. La carta è monospazio con lo strappo sopra e sotto, non un fumetto piatto: l'allineamento a colonne che gli spazi di `summary.js` producono si vede solo con un font a spaziatura fissa.
