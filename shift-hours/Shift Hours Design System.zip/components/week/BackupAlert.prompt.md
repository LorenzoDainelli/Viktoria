L'unica cosa arancione dell'app, e l'unica che tiene in vita i dati: sta fra i giorni e l'anteprima del messaggio, sulla strada che si percorre ogni domenica.

```jsx
<BackupAlert title="Back up August" onSave={share} />
```

Non aggiungere una ✕, non renderlo chiudibile, non riusare l'arancione altrove. Il cerchio pieno è l'unico bersaglio: 44×44, si preme con `scale(0.94)`.
