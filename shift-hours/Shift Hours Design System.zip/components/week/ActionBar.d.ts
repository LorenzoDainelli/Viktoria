import type { ReactNode } from 'react';

/** Barra ferma in fondo alla schermata settimana. Contiene una sola azione: `Copy summary`. */
export interface ActionBarProps {
  /** Riga di aiuto sotto il pulsante. Usarla raramente. */
  hint?: ReactNode;
  children?: ReactNode;
}

export function ActionBar(props: ActionBarProps): JSX.Element;
