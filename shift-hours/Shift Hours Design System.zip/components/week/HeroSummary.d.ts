import type { ReactNode } from 'react';

/**
 * Il blocco protagonista: il totale della settimana. È la ragione per cui l'app si apre.
 */
export interface HeroSummaryProps {
  /** Occhiello, es. `This week`. */
  label: string;
  /** Totale in formato ore.minuti, es. `31.40`. Numeri tabellari. */
  total: ReactNode;
  /** Unità accanto al numero. Default `hrs`. */
  unit?: string;
  /** Paga stimata già formattata, es. `316.67€`. Se manca, la riga non compare. */
  pay?: ReactNode;
  payLabel?: string;
  /** `<TypePill>`. */
  typePill?: ReactNode;
  /** Settimana in miniatura, 7 voci lunedì → domenica. Omesso = niente barrette. */
  week?: Array<{ on?: boolean; today?: boolean; pct?: number }>;
}

export function HeroSummary(props: HeroSummaryProps): JSX.Element;
