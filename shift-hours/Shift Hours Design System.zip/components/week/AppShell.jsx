import React from 'react';

export function AppShell({ header, footer, children }) {
  return (
    <div className="sh-app">
      {header}
      <div className="sh-app__body">{children}</div>
      {footer}
    </div>
  );
}
