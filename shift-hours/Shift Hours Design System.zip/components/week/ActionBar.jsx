import React from 'react';

export function ActionBar({ hint, children }) {
  return (
    <footer className="sh-actionbar">
      {children}
      {hint ? <span className="sh-actionbar__hint">{hint}</span> : null}
    </footer>
  );
}
