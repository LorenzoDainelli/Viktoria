L'unico modo per inserire un orario: si trascina, oppure si tocca − / + per spostarsi di 5 minuti esatti. Nessun campo da compilare.

```jsx
<TimeRange start={480} end={855} onChange={({ start, end }) => save(start, end)} />
```

Le etichette sotto la barra sono posizionate in percentuale, non distribuite: devono cadere esattamente sopra il punto che indicano. Maniglie: 34px visibili, 48px di area sensibile. `<NudgePair>` è esportato a parte solo per i casi in cui serve la coppia − / + senza barra.
