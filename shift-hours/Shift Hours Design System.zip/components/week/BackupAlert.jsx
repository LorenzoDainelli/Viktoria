import React from 'react';
import { Icon } from '../core/Icon.jsx';

export function BackupAlert({ title, note = 'Keep a copy of your hours on your phone.', onSave }) {
  return (
    <div className="sh-alert">
      <div className="sh-alert__text">
        <span className="sh-alert__title">{title}</span>
        <span className="sh-alert__note">{note}</span>
      </div>
      <button className="sh-alert__btn" type="button" aria-label={title} onClick={onSave}>
        <Icon name="download" size={20} />
      </button>
    </div>
  );
}
