Il blocco blu in cima: unico gradiente dell'interfaccia, unica ombra marcata, numero più grande della pagina (44px).

```jsx
<HeroSummary label="This week" total="31.40" pay="316.67€"
             typePill={<TypePill name="Week" onClick={openTypes} />} />
```

Uno solo per schermata. `pay` si omette quando la paga oraria non è impostata: l'app non mostra stime inventate.

`week` aggiunge sette barrette (lun → dom) accanto al totale: il ritmo della settimana si legge senza scorrere fino ai giorni. `pct` è l'altezza della barra sulle ore lavorate (0–100), `today` disegna il contorno.

```jsx
<HeroSummary label="This week" total="31.40" pay="316.67€"
             week={[{on:true,pct:83},{},{on:true,pct:62},{on:true,pct:82,today:true},{},{on:true,pct:83},{}]} />
```
