import React from 'react';

export function ScreenHeader({ eyebrow, title, actions }) {
  return (
    <header className="sh-header">
      <div>
        {eyebrow ? <span className="sh-header__eyebrow">{eyebrow}</span> : null}
        <h1 className="sh-header__title">{title}</h1>
      </div>
      {actions ? <div className="sh-header__actions">{actions}</div> : null}
    </header>
  );
}
