/**
 * Avviso della copia di sicurezza. Arancione: non è un errore e non distrugge niente.
 * **Non ha una ✕ e non deve averla**: resta finché il file non è stato davvero salvato.
 */
export interface BackupAlertProps {
  /** Es. `Back up August`. Serve anche da etichetta del pulsante. */
  title: string;
  /** Riga di spiegazione. Cambiarla solo con il testo inglese concordato. */
  note?: string;
  onSave?: () => void;
}

export function BackupAlert(props: BackupAlertProps): JSX.Element;
