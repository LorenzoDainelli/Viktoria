/**
 * Slider a due maniglie per l'orario di un giorno, a scatti di 5 minuti.
 * `-webkit-touch-callout: none` + `user-select: none` sono obbligatori: senza,
 * tenendo premuta una maniglia iOS apre la lente d'ingrandimento sugli orari.
 * Vibra 6ms a ogni scatto (drag e ± ): `navigator.vibrate`, ignorato in
 * silenzio dove non esiste (Safari iOS compreso).
 */
export interface TimeRangeProps {
  /** Inizio in minuti dalla mezzanotte. 480 = 8:00. */
  start?: number;
  /** Fine in minuti dalla mezzanotte. 855 = 14:15. */
  end?: number;
  /** Estremo sinistro della barra, in minuti. Default 360 (6:00). */
  min?: number;
  /** Estremo destro, in minuti. Default 1200 (20:00). */
  max?: number;
  /** Passo delle etichette sotto la barra, in minuti. Default 120 (ogni 2 ore). */
  scaleStep?: number;
  onChange?: (range: { start: number; end: number }) => void;
}

export interface NudgePairProps {
  groups: Array<{ label: string; onMinus?: () => void; onPlus?: () => void }>;
}

export function TimeRange(props: TimeRangeProps): JSX.Element;
export function NudgePair(props: NudgePairProps): JSX.Element;
