Testata fissa della settimana. Rispetta la safe area iOS (`padding-top: max(20px, env(safe-area-inset-top))`).

```jsx
<ScreenHeader eyebrow="Week ending" title="16 August" actions={<>
  <IconButton label="History"><Icon name="history" size={21} /></IconButton>
  <IconButton label="Settings"><Icon name="settings" size={21} /></IconButton>
</>} />
```

Mai più di tre azioni: la testata non è un menu.
