/**
 * Fumetto con il messaggio esatto che verrà incollato su WhatsApp.
 * Carta con lo strappo sopra e sotto, monospazio: è quello che allinea per
 * davvero le colonne che `src/js/summary.js` scrive con gli spazi.
 */
export interface MessagePreviewProps {
  label?: string;
  /** Testo con i ritorni a capo veri: il fumetto usa `white-space: pre-wrap`. */
  text: string;
}

export function MessagePreview(props: MessagePreviewProps): JSX.Element;
