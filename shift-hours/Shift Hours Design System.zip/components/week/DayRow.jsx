import React from 'react';
import { Icon } from '../core/Icon.jsx';

export function DayRow({ name, hours, times, today, open, onOpen, onClear, clearLabel = 'Clear day', children }) {
  const filled = Boolean(hours);
  return (
    <div className={'sh-day' + (filled && !open ? ' sh-day--filled' : '') + (open ? ' sh-day--open' : '')}>
      <button className="sh-day__head" type="button" onClick={onOpen}>
        <span className="sh-day__name">
          {today ? <span className="sh-day__today" /> : null}
          {name}
        </span>
        {filled ? (
          <span className="sh-day__value">
            <span className="sh-day__hours">{hours}</span>
            {times && !open ? <span className="sh-day__times">{times}</span> : null}
          </span>
        ) : (
          <span className="sh-day__add" aria-hidden="true">+</span>
        )}
      </button>
      {filled ? (
        <button className="sh-day__clear" type="button" aria-label={clearLabel} onClick={onClear}>
          <Icon name="close" size={18} />
        </button>
      ) : null}
      <div className="sh-day__reveal">
        <div>
          <div className="sh-day__panel">{children}</div>
        </div>
      </div>
    </div>
  );
}

export function DayList({ children }) {
  return <div className="sh-days">{children}</div>;
}
