Ogni scelta e ogni conferma arriva dal basso, dove sta il pollice. Mai un `confirm()` del browser, mai un dialogo al centro dello schermo.

```jsx
<Scrim open={askType} onClick={close} />
<Sheet open={askType} label="Choose week type">
  <SheetOption name="Week" days="Mon – Sun" selected />
  <SheetOption name="Weekend" days="Sat – Sun" />
</Sheet>

<Sheet open={confirm} title="Delete week ending 9 August?">
  <Button variant="danger">Delete</Button>
  <Button variant="ghost">Keep it</Button>
</Sheet>
```

La conferma dice sempre **cosa** sta per rimettere dentro o cancellare, con i numeri. Il rifiuto è un `ghost`, mai un secondo pulsante pieno.

`onClose` rende il foglio trascinabile in basso per chiuderlo: tocca la maniglia e trascina, oltre 90px si chiude, sotto risale al suo posto. Senza `onClose` il foglio si chiude solo dai suoi pulsanti — la scelta di quando offrirlo è del chiamante.
