import React, { useRef } from 'react';

export function Scrim({ open = true, onClick }) {
  return <div className="sh-scrim" hidden={!open} onClick={onClick} />;
}

export function Sheet({ open = true, title, label, onClose, children }) {
  const ref = useRef(null);

  const onPointerDown = (ev) => {
    if (!onClose || ev.target.closest('.sh-sheet__option')) return;
    const el = ref.current;
    const y0 = ev.clientY;
    el.classList.add('is-dragging');
    const move = (e) => { el.style.transform = 'translateY(' + Math.max(0, e.clientY - y0) + 'px)'; };
    const up = (e) => {
      window.removeEventListener('pointermove', move);
      window.removeEventListener('pointerup', up);
      el.classList.remove('is-dragging');
      el.classList.add('is-settling');
      if (e.clientY - y0 > 90) { el.style.transform = 'translateY(100%)'; setTimeout(onClose, 240); }
      else el.style.transform = '';
    };
    window.addEventListener('pointermove', move);
    window.addEventListener('pointerup', up);
  };

  return (
    <div className="sh-sheet" ref={ref} hidden={!open} role="dialog" aria-label={label} onPointerDown={onPointerDown}>
      <div className="sh-sheet__grip" />
      {title ? <p className="sh-sheet__title">{title}</p> : null}
      {children}
    </div>
  );
}

export function SheetOption({ name, days, selected, onSelect }) {
  return (
    <button
      className="sh-sheet__option"
      type="button"
      aria-selected={selected ? 'true' : 'false'}
      onClick={onSelect}
    >
      <span>{name}</span>
      {days ? <span className="sh-sheet__days">{days}</span> : null}
    </button>
  );
}
