Raggruppa le righe delle impostazioni. Nessun titolo grande, nessuna card: solo un occhiello e dello spazio.

```jsx
<Group label="Your hours" note="Last backup: August26 — 2 September">
  <Button variant="secondary">Download backup</Button>
</Group>
<Group label="Your hours" note="No backup yet" warn />
```

La nota è l'unico posto dove l'app spiega qualcosa, e lo fa in una riga.
