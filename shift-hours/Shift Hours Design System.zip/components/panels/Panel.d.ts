import type { ReactNode } from 'react';

/**
 * Schermata a copertura: storico e impostazioni. Titolo a sinistra, ✕ a destra.
 * `min-height: 0` sul corpo è obbligatorio, come nella shell.
 */
export interface PanelProps {
  /** Titolo in inglese: `History`, `Settings`. */
  title: ReactNode;
  onClose?: () => void;
  closeLabel?: string;
  /** Sostituisce la ✕ standard. Usare solo se serve davvero. */
  actions?: ReactNode;
  children?: ReactNode;
}

export interface LayerProps {
  /** Falso = `hidden`, che nel CSS dell'app vince su tutto. */
  open?: boolean;
  children?: ReactNode;
}

export function Panel(props: PanelProps): JSX.Element;
export function Layer(props: LayerProps): JSX.Element;
