import React from 'react';

export function SettingRow({ label, value, stacked, children }) {
  if (stacked) {
    return (
      <div className="sh-row sh-row--stacked">
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 'var(--sh-space-3)' }}>
          <span className="sh-row__label">{label}</span>
          {value}
        </div>
        {children}
      </div>
    );
  }
  return (
    <div className="sh-row">
      <span className="sh-row__label">{label}</span>
      {value !== undefined ? (typeof value === 'string' || typeof value === 'number'
        ? <span className="sh-row__value">{value}</span>
        : value) : null}
      {children}
    </div>
  );
}

export function RateInput({ currency = '€', value, placeholder = '—', onChange, label = 'Hourly rate' }) {
  return (
    <span className="sh-rate">
      <span className="sh-rate__currency">{currency}</span>
      <input
        className="sh-row__input"
        type="text"
        inputMode="decimal"
        placeholder={placeholder}
        aria-label={label}
        value={value}
        onChange={onChange}
      />
    </span>
  );
}

export function TypeNameInput({ value, onChange, label = 'Week type name' }) {
  return (
    <input className="sh-typename" type="text" aria-label={label} value={value} onChange={onChange} />
  );
}
