import type { ChangeEvent, ReactNode } from 'react';

/**
 * Riga delle impostazioni: etichetta a sinistra, valore o controllo a destra.
 */
export interface SettingRowProps {
  label: ReactNode;
  /** Testo spento a destra, o un controllo (`<RateInput>`, `<IconButton plain>`). */
  value?: ReactNode;
  /** Impila etichetta e contenuto: usato dalla riga con `<DayPicker>`. */
  stacked?: boolean;
  children?: ReactNode;
}

export interface RateInputProps {
  /** Simbolo di valuta mostrato a sinistra del campo. Default `€`. */
  currency?: string;
  value?: string;
  placeholder?: string;
  onChange?: (e: ChangeEvent<HTMLInputElement>) => void;
  label?: string;
}

export interface TypeNameInputProps {
  value?: string;
  onChange?: (e: ChangeEvent<HTMLInputElement>) => void;
  label?: string;
}

export function SettingRow(props: SettingRowProps): JSX.Element;
export function RateInput(props: RateInputProps): JSX.Element;
export function TypeNameInput(props: TypeNameInputProps): JSX.Element;
