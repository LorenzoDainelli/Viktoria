import type { ReactNode } from 'react';

/**
 * Foglio che entra dal basso: scelta del tipo di settimana, conferme prima di cancellare.
 */
export interface SheetProps {
  open?: boolean;
  /** Domanda o frase di conferma. Dice sempre cosa sta per accadere. */
  title?: ReactNode;
  /** `aria-label` del dialogo. */
  label?: string;
  /** Se presente, il foglio si trascina in basso per chiudersi (soglia 90px); si chiama a trascinamento concluso. */
  onClose?: () => void;
  children?: ReactNode;
}

export interface SheetOptionProps {
  name: ReactNode;
  /** Giorni del tipo, es. `Mon · Wed · Fri`. */
  days?: ReactNode;
  selected?: boolean;
  onSelect?: () => void;
}

export interface ScrimProps {
  open?: boolean;
  onClick?: () => void;
}

export function Sheet(props: SheetProps): JSX.Element;
export function SheetOption(props: SheetOptionProps): JSX.Element;
export function Scrim(props: ScrimProps): JSX.Element;
