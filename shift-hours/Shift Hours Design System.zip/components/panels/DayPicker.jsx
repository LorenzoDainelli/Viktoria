import React from 'react';

const LETTERS = ['M', 'T', 'W', 'T', 'F', 'S', 'S'];
const NAMES = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];

export function DayPicker({ selected = [], onToggle }) {
  return (
    <div className="sh-daypicker">
      {LETTERS.map((letter, i) => (
        <button
          key={NAMES[i]}
          className="sh-daypicker__day"
          type="button"
          aria-pressed={selected.includes(i) ? 'true' : 'false'}
          aria-label={NAMES[i]}
          onClick={onToggle ? () => onToggle(i) : undefined}
        >
          {letter}
        </button>
      ))}
    </div>
  );
}
