Le righe delle impostazioni. Altezza minima 60px, riempimento `--sh-surface`, nessun bordo.

```jsx
<SettingRow label="Hourly rate" value={<RateInput value={rate} onChange={setRate} />} />
<SettingRow label="Week" value="Mon – Sun" />
<SettingRow stacked label="☕ Mornings" value={<IconButton plain label="Delete"><Icon name="close" size={18} /></IconButton>}>
  <DayPicker selected={[0, 2, 4]} onToggle={toggle} />
</SettingRow>
```

I campi restano a 17px: sotto i 16px Safari zooma la pagina quando si scrive. Il campo paga parte **vuoto** — nel codice non c'è nessun importo.
