import type { ReactNode } from 'react';

/** Blocco delle impostazioni: occhiello, righe, nota di chiusura. */
export interface GroupProps {
  /** Occhiello maiuscoletto, es. `Pay`, `Week types`, `Your hours`. */
  label?: string;
  /** Nota sotto il blocco, es. `Leave it empty to hide estimated pay.` */
  note?: ReactNode;
  /** Tinge la nota d'arancione: solo per `No backup yet`. */
  warn?: boolean;
  children?: ReactNode;
}

export function Group(props: GroupProps): JSX.Element;
