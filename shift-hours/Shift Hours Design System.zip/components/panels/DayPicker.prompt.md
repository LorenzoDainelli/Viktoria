Le sette caselle dei giorni. Selezionato = blu pieno, tramite `aria-pressed="true"` — lo stato è nell'attributo, non in una classe.

```jsx
<DayPicker selected={[0, 2, 4]} onToggle={(i) => toggleDay(i)} />
```

Ogni casella è alta 44px e si allarga in parti uguali. Lettere sempre in inglese.
