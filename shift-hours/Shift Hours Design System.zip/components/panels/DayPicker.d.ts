/**
 * Sette caselle M T W T F S S per scegliere i giorni di un tipo di settimana.
 */
export interface DayPickerProps {
  /** Indici selezionati, 0 = lunedì. */
  selected?: number[];
  onToggle?: (index: number) => void;
}

export function DayPicker(props: DayPickerProps): JSX.Element;
