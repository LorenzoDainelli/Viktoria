import React from 'react';
import { IconButton } from '../core/IconButton.jsx';
import { Icon } from '../core/Icon.jsx';

export function Panel({ title, onClose, closeLabel = 'Close', actions, children }) {
  return (
    <div className="sh-panel">
      <header className="sh-panel__head">
        <span className="sh-panel__title">{title}</span>
        {actions || (
          <IconButton label={closeLabel} onClick={onClose}>
            <Icon name="close" size={18} />
          </IconButton>
        )}
      </header>
      <div className="sh-panel__body">{children}</div>
    </div>
  );
}

export function Layer({ open = true, children }) {
  return (
    <div className="sh-layer" hidden={!open}>
      {children}
    </div>
  );
}
