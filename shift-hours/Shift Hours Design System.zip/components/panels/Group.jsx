import React from 'react';

export function Group({ label, note, warn, children }) {
  return (
    <div className="sh-group">
      {label ? <span className="sh-group__label">{label}</span> : null}
      {children}
      {note ? <p className={'sh-group__note' + (warn ? ' sh-group__note--warn' : '')}>{note}</p> : null}
    </div>
  );
}
