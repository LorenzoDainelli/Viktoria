import type { ReactNode } from 'react';

/**
 * Riga dello storico: una settimana passata, riapribile identica a quella corrente.
 */
export interface HistoryRowProps {
  /** Es. `Week ending 9 August`. */
  week: ReactNode;
  /** Es. `2026 · 5 days`. */
  meta?: ReactNode;
  /** Totale, senza unità: `38.15`. */
  hours: ReactNode;
  onOpen?: () => void;
}

export function HistoryRow(props: HistoryRowProps): JSX.Element;
