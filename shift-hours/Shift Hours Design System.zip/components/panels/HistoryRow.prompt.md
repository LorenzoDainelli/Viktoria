Una settimana passata. Il totale è a destra, blu, tabellare: le righe si leggono in colonna.

```jsx
<HistoryRow week="Week ending 9 August" meta="2026 · 5 days" hours="38.15" onOpen={open} />
```

Ordine sempre dal più recente. Nessuna data numerica tipo `09/08/26`: mese scritto per esteso.
