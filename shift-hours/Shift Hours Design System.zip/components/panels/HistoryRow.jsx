import React from 'react';
import { Icon } from '../core/Icon.jsx';

export function HistoryRow({ week, meta, hours, onOpen }) {
  return (
    <button className="sh-histrow" type="button" onClick={onOpen}>
      <span className="sh-histrow__main">
        <span className="sh-histrow__week">{week}</span>
        {meta ? <span className="sh-histrow__meta">{meta}</span> : null}
      </span>
      <span className="sh-histrow__hours">{hours}</span>
      <span className="sh-histrow__chevron">
        <Icon name="chevronRight" size={18} />
      </span>
    </button>
  );
}
