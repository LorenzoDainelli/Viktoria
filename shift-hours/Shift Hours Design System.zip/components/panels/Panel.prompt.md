Le altre due schermate dell'app (`History`, `Settings`) sono pannelli a copertura, non pagine nuove.

```jsx
<Layer open={showHistory}>
  <Panel title="History" onClose={close}>
    <HistoryRow week="Week ending 9 August" meta="2026 · 5 days" hours="38.15" />
  </Panel>
</Layer>
```

Entrata: 12px dal basso + dissolvenza, 240ms. Si chiude solo con la ✕.
