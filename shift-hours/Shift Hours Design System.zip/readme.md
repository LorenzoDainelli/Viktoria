# Shift Hours — sistema di design

Shift Hours è una **web app per registrare le ore di lavoro della settimana** e
generare il messaggio pronto da mandare al capo su WhatsApp. Non è un prodotto
per un mercato: è un'app per **una persona** — Viktoria, barista in Irlanda,
madrelingua inglese, non tecnica, iPhone 15. La apre qualche volta a settimana
per segnare i turni e una volta a settimana per copiare il riepilogo.

Sito statico: HTML, CSS e JavaScript senza librerie, senza build, senza server.
Nessun account, nessun login. I dati vivono solo in `localStorage` sul suo
telefono: **nel repo non entra mai un orario o un importo reale**, e nemmeno in
questo progetto — tutti i numeri che vedi qui sono inventati.

Tre schermate in tutto: **settimana**, **storico**, **impostazioni**. Non ce ne
sono altre e non vanno aggiunte.

## Superfici del prodotto

Una sola: l'app installata sulla schermata home dell'iPhone (PWA, 393×852,
larghezza massima 440px, safe area iOS rispettata). Nessun sito di marketing,
nessuna area desktop, nessuna documentazione pubblica.

## Fonti di questo sistema

Tutto quello che c'è qui è stato letto dal codice reale, non da screenshot.

- Repo: **https://github.com/LorenzoDainelli/Viktoria** — branch `main`, cartella `shift-hours/`
  - `shift-hours/design_handoff/tokens/{colors,typography,space}.css` — i token, con i rapporti di contrasto annotati
  - `shift-hours/design_handoff/components.css` — il foglio componenti (le classi `sh-*`)
  - `shift-hours/design_handoff/reference.html` — il capitolato visivo: tutti i componenti e le schermate intere
  - `shift-hours/src/index.html`, `src/css/app.css` — il markup vero e le regole di layout dell'app
  - `shift-hours/README.md`, `PIANO-FASE-1-v2.md`, `PIANO-FASE-2.md`, `CLAUDE.md` — contratto e regole
- Briefing di redesign: `uploads/BRIEFINGDESIGN.md` (in questo progetto)
- Il branch `backup-shift-hours-v1.2` conserva la versione attualmente in uso.

Chi legge questo file e ha accesso al repo faccia un giro nei sorgenti: sono
poche centinaia di righe, commentate, e restano la verità.

### Il vincolo che governa tutto

**I nomi delle classi sono il contratto fra grafica e codice.** Metà
dell'interfaccia è costruita da `src/js/`: se una classe `sh-*` viene rinominata
o eliminata, non lo si scopre guardando la pagina — si spegne un pezzo di app in
silenzio. **Si possono aggiungere classi, mai rinominarle o eliminarle.** Le
modifiche si fanno in `design_handoff/` e poi si ricopiano in `src/css/`;
`src/index.html` e `src/js/*` non si toccano mai.

### Quattro regole CSS che sembrano estetiche e non lo sono

Sono correzioni di bug reali. Se `components.css` viene riscritto, vanno riportate.

| regola | dove | cosa succede senza |
|---|---|---|
| `-webkit-tap-highlight-color: transparent` | `html` | tenendo premuta una maniglia compare un rettangolo grigio scuro |
| `-webkit-touch-callout: none` + `user-select: none` | `.sh-range` | parte la lente d'ingrandimento sugli orari |
| `height: 100dvh` (non `min-height`) su `.sh-app`, `min-height: 0` su `.sh-app__body` e `.sh-panel__body` | shell | `Copy summary` finisce fuori schermo |
| area di tocco ≥ 44×44 | maniglie, ✕, ± , freccia dell'avviso, pulsanti tondi | bersagli che il dito manca |

## Indice del progetto

| file / cartella | cosa contiene |
|---|---|
| `styles.css` | punto d'ingresso: solo `@import`. È il file che i progetti consumatori collegano. |
| `tokens/colors.css` `typography.css` `space.css` | i token, copia fedele di `design_handoff/tokens/` |
| `css/components.css` `css/app.css` | il foglio componenti e le regole di layout dell'app, copia fedele del repo |
| `components/core/` | Icon, Button, IconButton, Chip, TypePill, Toast, Toasts, EmptyNote |
| `components/week/` | AppShell, ScreenHeader, HeroSummary, DayRow, DayList, TimeRange, NudgePair, BackupAlert, MessagePreview, ActionBar |
| `components/panels/` | Panel, Layer, Group, HistoryRow, SettingRow, RateInput, TypeNameInput, DayPicker, Sheet, SheetOption, Scrim |
| `ui_kits/shift-hours/` | le tre schermate cliccabili (`index.html`) |
| `templates/shift-hours-week/` | template di partenza: la schermata settimana, pronta da copiare |
| `guidelines/*.card.html` | i campioni di colore, tipografia, spazi, marchio |
| `assets/icons/` | gli 8 glifi dell'app in SVG + le due PNG dell'icona (segnaposto) |
| `github.md` | associazione col repo e mappa schermata → file |
| `SKILL.md` | uso di questo sistema come skill scaricabile |

### Componenti

`Icon` · `Button` · `IconButton` · `Chip` · `TypePill` · `Toast` · `Toasts` ·
`EmptyNote` · `AppShell` · `ScreenHeader` · `HeroSummary` · `DayRow` ·
`DayList` · `TimeRange` · `NudgePair` · `BackupAlert` · `MessagePreview` ·
`ActionBar` · `Panel` · `Layer` · `Group` · `HistoryRow` · `SettingRow` ·
`RateInput` · `TypeNameInput` · `DayPicker` · `Sheet` · `SheetOption` · `Scrim`

L'inventario è quello definito dal foglio componenti: un componente per famiglia
di classi `sh-*`. Ogni componente ha `.d.ts` (contratto dei prop) e `.prompt.md`
(quando si usa e quando no).

**Aggiunte volontarie**, non presenti come classe nel repo:

- `Icon` — involucro per gli 8 glifi SVG che nell'app sono scritti inline in `index.html`. Serve a non ridisegnarli a mano ogni volta.
- `AppShell`, `Layer`, `DayList`, `Toasts`, `Scrim` — involucri per `.sh-app`, `.sh-layer`, `.sh-days`, `.sh-toasts`, `.sh-scrim`, che nel repo sono contenitori nudi.
- `NudgePair`, `RateInput`, `TypeNameInput` — pezzi di `.sh-nudges`, `.sh-rate`, `.sh-typename` esposti separatamente.

## Fondamenti visivi

**Impianto.** Superfici piene, non bordi. Le card si distinguono per
riempimento; i bordi grigi ovunque fanno sembrare l'app un modulo da compilare.
Un solo blocco protagonista in cima (il totale della settimana), righe alte,
raggi larghi, ritmo verticale regolare. I numeri sono il contenuto: grandi,
tabellari, in evidenza.

**Colore.** Bianco e blu `#1B47C9`, scelti dalla persona che usa l'app: si
lavora sulle gradazioni, non si sostituisce l'identità. **Solo tema chiaro**,
nessuna modalità scura. Tre ruoli che devono restare distinguibili a colpo
d'occhio: **azione** = blu; **eliminare** = rosso `#CC2B1D`; **copia di
sicurezza** = arancione `#A34A00` su `#FFF3E3`, che non è un errore e non
distrugge niente, quindi non condivide il colore col rosso. Grigi e neri hanno
una punta di blu (`#0B0F19`, `#646C81`), non sono neutri da default. Ogni colore
porta scritto accanto il suo rapporto di contrasto: **AA, 4.5:1 minimo**, e ogni
colore nuovo va annotato allo stesso modo. Nessun colore scritto a mano fuori
dai token: se manca un valore, si aggiunge un token.

**Sfondi.** Bianco, sempre. Nessuna immagine, nessuna texture, nessun pattern,
nessuna illustrazione. **Un solo gradiente in tutta l'app**: il blocco del
totale (`linear-gradient(140deg, #1B47C9, #3A6BF0)`), ripreso dal riempimento
dello slider. Un secondo gradiente altrove romperebbe la gerarchia.

**Tipografia.** Font di sistema (`-apple-system`, `SF Pro Text` su iPhone):
nessun font da scaricare, nessun rischio offline. Scala volutamente ampia,
11 → 44px, perché i numeri devono dominare: 44px il totale, 34px gli orari nello
slider, 17px il corpo (misura di sistema iOS — sotto 16px Safari zooma quando si
scrive), 11px gli occhielli maiuscoletti con tracking `0.08em`. Tracking negativo
sui numeri grandi (`-0.03em`), `font-variant-numeric: tabular-nums` su ogni cifra
che può cambiare.

**Spazi e raggi.** Scala da 4px, gutter di schermata 20px, spazio fra le righe
8px, fra i blocchi 20px. Raggi generosi: 12px (campi), 18px (righe dei giorni),
24px (riepilogo e pannelli aperti), pillola (pulsanti, maniglie, caselle).

**Card.** Nessun bordo, nessuna ombra sulle superfici a riposo: una card è un
rettangolo di colore diverso con angoli larghi. L'ombra compare **solo** su ciò
che sta sopra: `--sh-shadow-hero` sul blocco del totale, `--sh-shadow-md` sul
giorno aperto e sui toast, `--sh-shadow-bar` verso l'alto sulla barra d'azione,
`--sh-shadow-sm` sui pulsanti − / +. Tutte in `hsl(224 40% 20% / …)`: ombre
blu-grigie, mai nere.

**Stati.** Niente hover: si usa col dito. La pressione è un cambio di
riempimento, non un movimento: blu → `#14349B`, `--sh-surface` →
`--sh-surface-strong`, arancione → `#843C00`. Due sole trasformazioni in tutta
l'app: la maniglia dello slider cresce (`scale(1.12)`) e il cerchio dell'avviso
si comprime (`scale(0.94)`). Focus visibile: contorno blu 3px con offset 3px.
Disattivato: `--sh-disabled-bg`, testo `--sh-disabled-text`, ombra via.

**Movimento.** Breve e mai vistoso: 140ms le pressioni, 240ms tutto il resto,
un'unica curva `cubic-bezier(0.32, 0.72, 0, 1)`. Tre movimenti in tutto:
pannello che entra (12px dal basso + dissolvenza), foglio che sale dal bordo,
toast che appare e sparisce. Con `prefers-reduced-motion` le durate vanno a
zero.

**Trasparenza e sfocature.** Una sola trasparenza: la pillola del tipo di
settimana sul blu (`hsl(0 0% 100% / 0.16)`), più lo scrim dei fogli
(`hsl(224 40% 20% / 0.4)`). **Nessun `backdrop-filter`**, nessun vetro
smerigliato: costa batteria e non aggiunge niente.

**Layout.** Larghezza massima 440px centrata. Sulla schermata settimana due
elementi non si muovono mai — la testata e la barra d'azione — e scorre solo la
lista dei giorni. Storico e impostazioni sono livelli `position: fixed` a
copertura, non pagine nuove. I fogli di scelta e le conferme arrivano dal basso,
dove sta il pollice. **Niente scorrimento orizzontale a 390px**, mai.

## Fondamenti di contenuto

**Tutta l'interfaccia è in inglese** e non va tradotta né riscritta. La
documentazione (compreso questo file e i campioni) è in italiano: è materiale
interno.

**Tono.** Frasi brevi, seconda persona implicita, mai "io". Nessun termine
tecnico visibile: si dice `Your hours`, non "dati"; `Back up August`, non
"esporta JSON". Se un'interazione richiede una spiegazione, va semplificata,
non spiegata.

**Casing.** Etichette e pulsanti in *sentence case*: `Copy summary`,
`Download backup`, `Restore from backup`, `Add week type`, `Keep it`. Solo gli
occhielli sono maiuscoletti: `WEEK ENDING`, `MESSAGE PREVIEW`, `YOUR HOURS`,
`START` / `END`.

**Date e numeri.** Mese scritto per esteso, giorno prima: `Week ending
16 August`, `Last backup: August26 — 2 September`. Mai `09/08/26`. Le ore in
formato ore.minuti con l'unità staccata: `31.40 hrs`, `8.30 hrs`. Nel messaggio
finale, però, si scrive a parole: `31 hours and 40 minutes`.

**Punteggiatura.** Le etichette non hanno punto finale; le note in una frase
compiuta sì (`Leave it empty to hide estimated pay.`,
`Keep a copy of your hours on your phone.`). Le conferme sono domande che dicono
cosa sta per accadere, con i numeri dentro: `This backup ends on 30 August and
has 14 weeks. Restore it?`. Il rifiuto è umano: `Keep it`, non "Annulla".

**Emoji.** Non fanno parte del sistema, con una sola eccezione: il nome di un
tipo di settimana lo scrive lei, e può metterci quello che vuole (`☕ Mornings`).
Non aggiungerne altrove.

**Vibe.** Nessun entusiasmo, nessuna congratulazione, nessun onboarding. L'app
conferma con una parola (`Copied`) e sta zitta.

## Iconografia

**Nessuna libreria di icone.** L'app ne ha **otto**, scritte inline in
`src/index.html`: `history` (orologio), `settings` (due cursori), `close` (✕),
`chevron-right`, `chevron-left`, `chevron-down`, `check` (spunta), `download`
(freccia in giù su una linea). Sono state estratte così come sono in
`assets/icons/*.svg` e sono esposte dal componente `Icon`.

Regole del set: viewBox `24 24`, `fill: none`, `stroke: currentColor`, estremi e
giunzioni tonde, tratto 2 sulle icone di testata e 2.4 su tutte le altre, 3 sui
chevron piccoli. Misure d'uso: 21px nella testata, 18px nelle righe, 20px nei
toast e nell'avviso. **Non aggiungere glifi**: se serve un simbolo nuovo, prima
si verifica se serve davvero un'icona.

Tre simboli **non** sono icone ma testo, e devono restarlo: il `+` del giorno
vuoto, i `−` / `+` della regolazione fine, il `–` fra gli orari.

Nessun'altra immagine nel prodotto: nessuna illustrazione, nessuna foto, nessuna
emoji di sistema.

### Marchio

**Shift Hours non ha un logo.** Non ne esiste uno nei sorgenti e non ne è stato
disegnato uno qui: dove servirebbe un marchio si scrive il nome in tipografia
semplice. Le due icone dell'app (`assets/icons/app-icon-192.png`,
`app-icon-512.png`) sono **segnaposto dichiarati** — un quadrato blu con una "S"
bianca — e vanno sostituite conservando gli stessi nomi di file, perché
`manifest.webmanifest` e `apple-touch-icon` li citano. Essendo `maskable`, il
soggetto deve stare nel cerchio di sicurezza centrale.

## Font

Nessun file di font, per scelta: lo stack è
`-apple-system, BlinkMacSystemFont, "SF Pro Text", "Segoe UI", Roboto,
"Helvetica Neue", Arial, sans-serif`. Su iPhone rende San Francisco, già
installato. Non sostituire con un font Google e non aggiungere `@font-face`:
un font da scaricare è peso in più e un rischio offline su un'app che deve
funzionare sempre.
