repo: LorenzoDainelli/Viktoria
branch: main
path: shift-hours

## Last sync

date: 2026-08-14T11:23:34Z

### Updated in this project

- Token CSS (colori, tipografia, spazi) copiati fedelmente da `design_handoff/tokens/`.
- `components.css` e `app.css` copiati: le classi `sh-*` sono il contratto con il JS.
- Icone dell'app estratte in `assets/icons/` (8 glifi + le due PNG segnaposto).
- UI kit con le tre schermate ricostruite dai sorgenti, non da screenshot.

## Screen map

| schermata / file di questo progetto | file del repo |
|---|---|
| `tokens/colors.css` | `shift-hours/design_handoff/tokens/colors.css` |
| `tokens/typography.css` | `shift-hours/design_handoff/tokens/typography.css` |
| `tokens/space.css` | `shift-hours/design_handoff/tokens/space.css` |
| `css/components.css` | `shift-hours/design_handoff/components.css` |
| `css/app.css` | `shift-hours/src/css/app.css` |
| `components/**` | `shift-hours/design_handoff/components.css` + `shift-hours/design_handoff/reference.html` |
| `ui_kits/shift-hours/WeekScreen.jsx` | `shift-hours/src/index.html`, `shift-hours/design_handoff/reference.html` |
| `ui_kits/shift-hours/HistoryScreen.jsx` | `shift-hours/src/index.html` (`#history-layer`), `reference.html` schermata 3 |
| `ui_kits/shift-hours/SettingsScreen.jsx` | `shift-hours/src/index.html` (`#settings-layer`), `reference.html` schermata 4 |
| `assets/icons/*` | SVG inline di `shift-hours/src/index.html`, `shift-hours/src/icons/*` |
