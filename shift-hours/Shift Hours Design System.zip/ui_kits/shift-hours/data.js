/* Dati d'esempio interamente inventati: nel repo non entra mai un orario reale. */
window.SH_DATA = {
  weekEnding: '16 August',
  days: [
    { name: 'Monday',    start: 480, end: 990 },
    { name: 'Tuesday',   start: null, end: null },
    { name: 'Wednesday', start: 480, end: 855 },
    { name: 'Thursday',  start: 540, end: 1045, today: true },
    { name: 'Friday',    start: null, end: null },
    { name: 'Saturday',  start: 510, end: 1020 },
    { name: 'Sunday',    start: null, end: null },
  ],
  history: [
    { week: 'Week ending 9 August',  meta: '2026 · 5 days', hours: '38.15' },
    { week: 'Week ending 2 August',  meta: '2026 · 5 days', hours: '41.00' },
    { week: 'Week ending 26 July',   meta: '2026 · 2 days', hours: '15.00' },
    { week: 'Week ending 19 July',   meta: '2026 · 4 days', hours: '35.30' },
    { week: 'Week ending 12 July',   meta: '2026 · 5 days', hours: '47.00' },
  ],
  types: [
    { name: 'Week', days: 'Mon – Sun' },
    { name: 'Weekend', days: 'Sat – Sun' },
    { name: '☕ Mornings', days: 'Mon · Wed · Fri' },
  ],
};

window.SH_FMT = {
  clock(min) { return Math.floor(min / 60) + ':' + String(min % 60).padStart(2, '0'); },
  hours(min) { return Math.floor(min / 60) + '.' + String(min % 60).padStart(2, '0'); },
  words(min) { return Math.floor(min / 60) + ' hours and ' + (min % 60) + ' minutes'; },
};
