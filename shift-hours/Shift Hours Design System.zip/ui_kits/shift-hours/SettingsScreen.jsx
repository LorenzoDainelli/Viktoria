const {
  Layer, Panel, Group, SettingRow, RateInput, DayPicker, Button, IconButton, Icon,
} = window.ShiftHoursDesignSystem_074dd2;

function SettingsScreen({ open, rate, types, lastBackup, onClose, onRate, onBackup }) {
  const [morningDays, setMorningDays] = React.useState([0, 2, 4]);
  const toggle = (i) => setMorningDays((d) => (d.includes(i) ? d.filter((x) => x !== i) : d.concat(i).sort()));

  return (
    <Layer open={open}>
      <Panel title="Settings" onClose={onClose}>
        <Group label="Pay" note="Leave it empty to hide estimated pay.">
          <SettingRow
            label="Hourly rate"
            value={<RateInput value={rate} onChange={(e) => onRate(e.target.value)} />}
          />
        </Group>

        <Group label="Week types">
          {types.slice(0, 2).map((t) => (
            <SettingRow key={t.name} label={t.name} value={t.days} />
          ))}
          <SettingRow
            stacked
            label="☕ Mornings"
            value={<IconButton plain label="Delete week type"><Icon name="close" size={18} /></IconButton>}
          >
            <DayPicker selected={morningDays} onToggle={toggle} />
          </SettingRow>
          <Button variant="secondary">Add week type</Button>
        </Group>

        <Group label="Your hours" note={lastBackup || 'No backup yet'} warn={!lastBackup}>
          <Button variant="secondary" onClick={onBackup}>Download backup</Button>
          <Button variant="secondary">Restore from backup</Button>
        </Group>
      </Panel>
    </Layer>
  );
}

window.SettingsScreen = SettingsScreen;
