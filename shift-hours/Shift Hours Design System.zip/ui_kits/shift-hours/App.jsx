const { Scrim, Sheet, SheetOption, Toast, Toasts, Button } = window.ShiftHoursDesignSystem_074dd2;
const { WeekScreen, HistoryScreen, SettingsScreen } = window;
const DATA = window.SH_DATA;

function App() {
  const [days, setDays] = React.useState(DATA.days);
  const [openDay, setOpenDay] = React.useState(null);
  const [weekEnding, setWeekEnding] = React.useState(DATA.weekEnding);
  const [pastWeek, setPastWeek] = React.useState(false);
  const [type, setType] = React.useState('Week');
  const [rate, setRate] = React.useState('');
  const [screen, setScreen] = React.useState(null);
  const [sheet, setSheet] = React.useState(null);
  const [backupDue, setBackupDue] = React.useState(true);
  const [lastBackup, setLastBackup] = React.useState(null);
  const [toasts, setToasts] = React.useState([]);

  const say = (text) => {
    const id = Date.now() + Math.random();
    setToasts((t) => t.concat({ id, text }));
    setTimeout(() => setToasts((t) => t.filter((x) => x.id !== id)), 2600);
  };

  const actions = {
    toggleDay: (i) => setOpenDay((o) => (o === i ? null : i)),
    setDay: (i, r) => setDays((d) => d.map((x, n) => (n === i ? { ...x, start: r.start, end: r.end } : x))),
    clearDay: (i) => {
      setDays((d) => d.map((x, n) => (n === i ? { ...x, start: null, end: null } : x)));
      setOpenDay((o) => (o === i ? null : o));
    },
    copy: (text) => { navigator.clipboard?.writeText(text).catch(() => {}); say('Copied'); },
    openHistory: () => setScreen('history'),
    openSettings: () => setScreen('settings'),
    openTypes: () => setSheet('types'),
    confirmClearWeek: () => setSheet('confirm'),
    backToCurrent: () => { setPastWeek(false); setWeekEnding(DATA.weekEnding); setDays(DATA.days); setOpenDay(null); },
    backup: () => { setBackupDue(false); setLastBackup('Last backup: August26 — 14 August'); say('Backup saved'); },
  };

  return (
    <>
      <WeekScreen
        state={{ days, openDay, weekEnding, type, rate, pastWeek, backupDue }}
        actions={actions}
      />

      <HistoryScreen
        open={screen === 'history'}
        weeks={DATA.history}
        onClose={() => setScreen(null)}
        onOpenWeek={(wk) => {
          setPastWeek(true);
          setWeekEnding(wk.week.replace('Week ending ', ''));
          setDays(DATA.days.map((d, i) => (i % 2 ? { ...d, start: null, end: null } : { ...d, today: false })));
          setScreen(null);
          setOpenDay(null);
        }}
      />

      <SettingsScreen
        open={screen === 'settings'}
        rate={rate}
        types={DATA.types}
        lastBackup={lastBackup}
        onClose={() => setScreen(null)}
        onRate={setRate}
        onBackup={actions.backup}
      />

      <Scrim open={sheet !== null} onClick={() => setSheet(null)} />

      <Sheet open={sheet === 'types'} label="Choose week type">
        {DATA.types.map((t) => (
          <SheetOption
            key={t.name}
            name={t.name}
            days={t.days}
            selected={t.name === type}
            onSelect={() => { setType(t.name); setSheet(null); }}
          />
        ))}
      </Sheet>

      <Sheet
        open={sheet === 'confirm'}
        label="Are you sure?"
        title={(pastWeek ? 'Delete week ending ' : 'Clear week ending ') + weekEnding + '?'}
      >
        <Button
          variant="danger"
          onClick={() => {
            setDays((d) => d.map((x) => ({ ...x, start: null, end: null })));
            setSheet(null);
            say(pastWeek ? 'Week deleted' : 'Week cleared');
          }}
        >
          {pastWeek ? 'Delete' : 'Clear'}
        </Button>
        <Button variant="ghost" onClick={() => setSheet(null)}>Keep it</Button>
      </Sheet>

      <Toasts>
        {toasts.map((t) => <Toast key={t.id}>{t.text}</Toast>)}
      </Toasts>
    </>
  );
}

ReactDOM.createRoot(document.getElementById('root')).render(<App />);
