const {
  AppShell, ScreenHeader, ActionBar, HeroSummary, TypePill, DayList, DayRow,
  TimeRange, BackupAlert, MessagePreview, Button, IconButton, Icon, Chip,
} = window.ShiftHoursDesignSystem_074dd2;
const F = window.SH_FMT;

function WeekScreen({ state, actions }) {
  const { days, openDay, weekEnding, type, rate, pastWeek, backupDue } = state;
  const worked = days.filter((d) => d.start != null);
  const totalMin = worked.reduce((n, d) => n + (d.end - d.start), 0);
  const pay = rate ? (totalMin / 60 * Number(rate)).toFixed(2) + '€' : null;

  const summary = ['Week ending ' + weekEnding]
    .concat(worked.map((d) => d.name + ': ' + F.clock(d.start) + ' - ' + F.clock(d.end) + ' ' + F.hours(d.end - d.start) + ' hrs'))
    .concat([F.words(totalMin)])
    .join('\n');

  return (
    <AppShell
      header={
        <ScreenHeader
          eyebrow="Week ending"
          title={weekEnding}
          actions={
            <>
              {pastWeek ? (
                <Chip onClick={actions.backToCurrent}><Icon name="chevronLeft" size={14} /> This week</Chip>
              ) : null}
              <IconButton label="History" onClick={actions.openHistory}><Icon name="history" size={21} /></IconButton>
              <IconButton label="Settings" onClick={actions.openSettings}><Icon name="settings" size={21} /></IconButton>
            </>
          }
        />
      }
      footer={
        <ActionBar>
          <Button disabled={!worked.length} onClick={() => actions.copy(summary)}>Copy summary</Button>
        </ActionBar>
      }
    >
      <HeroSummary
        label={pastWeek ? 'Saved week' : 'This week'}
        total={F.hours(totalMin)}
        pay={pay}
        typePill={<TypePill name={type} onClick={actions.openTypes} />}
      />

      <DayList>
        {days.map((d, i) => (
          <DayRow
            key={d.name}
            name={d.name}
            today={d.today}
            hours={d.start != null ? F.hours(d.end - d.start) + ' hrs' : undefined}
            times={d.start != null ? F.clock(d.start) + ' – ' + F.clock(d.end) : undefined}
            open={openDay === i}
            onOpen={() => actions.toggleDay(i)}
            onClear={() => actions.clearDay(i)}
            clearLabel={'Clear ' + d.name}
          >
            <TimeRange
              key={'r' + i}
              start={d.start ?? 480}
              end={d.end ?? 960}
              onChange={(r) => actions.setDay(i, r)}
            />
          </DayRow>
        ))}
      </DayList>

      {backupDue ? <BackupAlert title="Back up August" onSave={actions.backup} /> : null}

      {worked.length ? <MessagePreview text={summary} /> : null}

      {worked.length ? (
        <div className="sh-group">
          <Button variant="danger" onClick={actions.confirmClearWeek}>
            {pastWeek ? 'Delete week' : 'Clear week'}
          </Button>
        </div>
      ) : null}
    </AppShell>
  );
}

window.WeekScreen = WeekScreen;
