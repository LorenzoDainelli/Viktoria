# UI kit — Shift Hours (app)

Ricostruzione delle **tre schermate** dell'app in uso: settimana, storico,
impostazioni. Composta con i componenti del sistema, non con CSS nuovo.

- `index.html` — l'app cliccabile, larghezza iPhone 15 (393px).
- `data.js` — dati d'esempio **inventati** e i tre formattatori di orario.
- `WeekScreen.jsx` — la schermata principale: totale, giorni, slider, avviso, anteprima.
- `HistoryScreen.jsx` — pannello dello storico.
- `SettingsScreen.jsx` — pannello impostazioni: paga, tipi di settimana, copie di sicurezza.
- `App.jsx` — stato e passaggi fra le schermate.

## Cosa si può provare

Toccare un giorno apre lo slider dentro la riga (maniglie trascinabili, − / + a
scatti di 5 minuti); la ✕ svuota il giorno; `Copy summary` copia il messaggio e
mostra un toast; la pillola blu apre la scelta del tipo di settimana; la freccia
dell'avviso arancione "salva" la copia e fa sparire l'avviso; `Clear week` chiede
conferma dal basso. Storico e impostazioni si aprono a copertura.

## Cosa è finto

Nessun `localStorage`, nessun service worker, nessun file di backup vero: qui si
approva l'aspetto, non il funzionamento. L'app vera è in
`shift-hours/src/` nel repo LorenzoDainelli/Viktoria.
