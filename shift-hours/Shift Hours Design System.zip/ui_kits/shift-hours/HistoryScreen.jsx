const { Layer, Panel, HistoryRow, EmptyNote } = window.ShiftHoursDesignSystem_074dd2;

function HistoryScreen({ open, weeks, onClose, onOpenWeek }) {
  return (
    <Layer open={open}>
      <Panel title="History" onClose={onClose}>
        {weeks.length ? (
          weeks.map((wk) => (
            <HistoryRow key={wk.week} week={wk.week} meta={wk.meta} hours={wk.hours} onOpen={() => onOpenWeek(wk)} />
          ))
        ) : (
          <EmptyNote>No saved weeks yet.</EmptyNote>
        )}
      </Panel>
    </Layer>
  );
}

window.HistoryScreen = HistoryScreen;
