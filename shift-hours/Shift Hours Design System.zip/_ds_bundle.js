/* @ds-bundle: {"format":4,"namespace":"ShiftHoursDesignSystem_074dd2","components":[{"name":"Button","sourcePath":"components/core/Button.jsx"},{"name":"Chip","sourcePath":"components/core/Chip.jsx"},{"name":"EmptyNote","sourcePath":"components/core/EmptyNote.jsx"},{"name":"Icon","sourcePath":"components/core/Icon.jsx"},{"name":"IconButton","sourcePath":"components/core/IconButton.jsx"},{"name":"Toast","sourcePath":"components/core/Toast.jsx"},{"name":"Toasts","sourcePath":"components/core/Toast.jsx"},{"name":"TypePill","sourcePath":"components/core/TypePill.jsx"},{"name":"DayPicker","sourcePath":"components/panels/DayPicker.jsx"},{"name":"Group","sourcePath":"components/panels/Group.jsx"},{"name":"HistoryRow","sourcePath":"components/panels/HistoryRow.jsx"},{"name":"Panel","sourcePath":"components/panels/Panel.jsx"},{"name":"Layer","sourcePath":"components/panels/Panel.jsx"},{"name":"SettingRow","sourcePath":"components/panels/SettingRow.jsx"},{"name":"RateInput","sourcePath":"components/panels/SettingRow.jsx"},{"name":"TypeNameInput","sourcePath":"components/panels/SettingRow.jsx"},{"name":"Scrim","sourcePath":"components/panels/Sheet.jsx"},{"name":"Sheet","sourcePath":"components/panels/Sheet.jsx"},{"name":"SheetOption","sourcePath":"components/panels/Sheet.jsx"},{"name":"ActionBar","sourcePath":"components/week/ActionBar.jsx"},{"name":"AppShell","sourcePath":"components/week/AppShell.jsx"},{"name":"BackupAlert","sourcePath":"components/week/BackupAlert.jsx"},{"name":"DayRow","sourcePath":"components/week/DayRow.jsx"},{"name":"DayList","sourcePath":"components/week/DayRow.jsx"},{"name":"HeroSummary","sourcePath":"components/week/HeroSummary.jsx"},{"name":"MessagePreview","sourcePath":"components/week/MessagePreview.jsx"},{"name":"ScreenHeader","sourcePath":"components/week/ScreenHeader.jsx"},{"name":"TimeRange","sourcePath":"components/week/TimeRange.jsx"},{"name":"NudgePair","sourcePath":"components/week/TimeRange.jsx"}],"sourceHashes":{"components/core/Button.jsx":"6b3057f85dcb","components/core/Chip.jsx":"82a186ee3313","components/core/EmptyNote.jsx":"cdca634445fa","components/core/Icon.jsx":"7bbfb75c7733","components/core/IconButton.jsx":"2a1f18114886","components/core/Toast.jsx":"c5356acea502","components/core/TypePill.jsx":"6b6b6b158005","components/panels/DayPicker.jsx":"01ad40af7661","components/panels/Group.jsx":"6cd3b5da95ed","components/panels/HistoryRow.jsx":"e1aa682dbd1c","components/panels/Panel.jsx":"a3c0fa51402b","components/panels/SettingRow.jsx":"a747f20f0017","components/panels/Sheet.jsx":"1abbffbb6470","components/week/ActionBar.jsx":"2deafdea117c","components/week/AppShell.jsx":"b13ef4c68ffe","components/week/BackupAlert.jsx":"733739649f99","components/week/DayRow.jsx":"4ae076a97f5a","components/week/HeroSummary.jsx":"6473c48c0c64","components/week/MessagePreview.jsx":"0db679971e06","components/week/ScreenHeader.jsx":"396b22dfc4bc","components/week/TimeRange.jsx":"916f40a9326f","ui_kits/shift-hours/App.jsx":"80f77e1f65b8","ui_kits/shift-hours/HistoryScreen.jsx":"f46229ac55f4","ui_kits/shift-hours/SettingsScreen.jsx":"8cb6f90c44c9","ui_kits/shift-hours/WeekScreen.jsx":"21f11a963a4c","ui_kits/shift-hours/data.js":"abdfa98514ac"},"inlinedExternals":[],"unexposedExports":[]} */

(() => {

const __ds_ns = (window.ShiftHoursDesignSystem_074dd2 = window.ShiftHoursDesignSystem_074dd2 || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// components/core/Button.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const VARIANT = {
  primary: '',
  secondary: ' sh-btn--secondary',
  danger: ' sh-btn--danger',
  ghost: ' sh-btn--ghost'
};
function Button({
  variant = 'primary',
  disabled,
  className = '',
  children,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("button", _extends({
    type: "button",
    className: 'sh-btn' + VARIANT[variant] + (className ? ' ' + className : ''),
    disabled: disabled
  }, rest), children);
}
Object.assign(__ds_scope, { Button });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Button.jsx", error: String((e && e.message) || e) }); }

// components/core/Chip.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Chip({
  className = '',
  children,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("button", _extends({
    type: "button",
    className: 'sh-chip' + (className ? ' ' + className : '')
  }, rest), children);
}
Object.assign(__ds_scope, { Chip });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Chip.jsx", error: String((e && e.message) || e) }); }

// components/core/EmptyNote.jsx
try { (() => {
function EmptyNote({
  children
}) {
  return /*#__PURE__*/React.createElement("p", {
    className: "sh-empty"
  }, children);
}
Object.assign(__ds_scope, { EmptyNote });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/EmptyNote.jsx", error: String((e && e.message) || e) }); }

// components/core/Icon.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/* Il set di icone dell'app: gli stessi path dell'SVG inline in src/index.html.
   Nessuna icona nuova: se serve un glifo, si aggiunge qui copiandolo dal repo. */
const PATHS = {
  history: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("circle", {
    cx: "12",
    cy: "12",
    r: "9"
  }), /*#__PURE__*/React.createElement("path", {
    d: "M12 7.5V12l3 2"
  })),
  settings: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("path", {
    d: "M4 8.5h16M4 15.5h16"
  }), /*#__PURE__*/React.createElement("circle", {
    cx: "15",
    cy: "8.5",
    r: "2.4",
    fill: "currentColor",
    stroke: "none"
  }), /*#__PURE__*/React.createElement("circle", {
    cx: "9",
    cy: "15.5",
    r: "2.4",
    fill: "currentColor",
    stroke: "none"
  })),
  close: /*#__PURE__*/React.createElement("path", {
    d: "M6 6l12 12M18 6L6 18"
  }),
  chevronRight: /*#__PURE__*/React.createElement("path", {
    d: "M9 5l7 7-7 7"
  }),
  chevronLeft: /*#__PURE__*/React.createElement("path", {
    d: "M15 5l-7 7 7 7"
  }),
  chevronDown: /*#__PURE__*/React.createElement("path", {
    d: "M6 9l6 6 6-6"
  }),
  check: /*#__PURE__*/React.createElement("path", {
    d: "M4 12.5l5 5L20 7"
  }),
  download: /*#__PURE__*/React.createElement("path", {
    d: "M12 4v11m0 0l-4.5-4.5M12 15l4.5-4.5M5 19.5h14"
  })
};
const WEIGHT = {
  history: 2,
  settings: 2,
  chevronLeft: 3,
  chevronDown: 3
};
function Icon({
  name,
  size = 20,
  strokeWidth,
  style,
  ...rest
}) {
  const glyph = PATHS[name];
  if (!glyph) return null;
  return /*#__PURE__*/React.createElement("svg", _extends({
    width: size,
    height: size,
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: strokeWidth ?? WEIGHT[name] ?? 2.4,
    strokeLinecap: "round",
    strokeLinejoin: "round",
    "aria-hidden": "true",
    style: {
      flex: 'none',
      display: 'block',
      ...style
    }
  }, rest), glyph);
}
Object.assign(__ds_scope, { Icon });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Icon.jsx", error: String((e && e.message) || e) }); }

// components/core/IconButton.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function IconButton({
  label,
  plain,
  className = '',
  children,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("button", _extends({
    type: "button",
    "aria-label": label,
    className: 'sh-iconbtn' + (plain ? ' sh-iconbtn--plain' : '') + (className ? ' ' + className : '')
  }, rest), children);
}
Object.assign(__ds_scope, { IconButton });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/IconButton.jsx", error: String((e && e.message) || e) }); }

// components/core/Toast.jsx
try { (() => {
function Toast({
  children,
  leaving,
  icon = true
}) {
  return /*#__PURE__*/React.createElement("div", {
    className: 'sh-toast' + (leaving ? ' sh-toast--leaving' : '')
  }, icon ? /*#__PURE__*/React.createElement("span", {
    className: "sh-toast__icon"
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "check",
    size: 20
  })) : null, children);
}
function Toasts({
  children
}) {
  return /*#__PURE__*/React.createElement("div", {
    className: "sh-toasts",
    "aria-live": "polite"
  }, children);
}
Object.assign(__ds_scope, { Toast, Toasts });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Toast.jsx", error: String((e && e.message) || e) }); }

// components/core/TypePill.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function TypePill({
  name,
  showCaret = true,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("button", _extends({
    type: "button",
    className: "sh-typepill"
  }, rest), /*#__PURE__*/React.createElement("span", null, name), showCaret ? /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "chevronDown",
    size: 14
  }) : null);
}
Object.assign(__ds_scope, { TypePill });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/TypePill.jsx", error: String((e && e.message) || e) }); }

// components/panels/DayPicker.jsx
try { (() => {
const LETTERS = ['M', 'T', 'W', 'T', 'F', 'S', 'S'];
const NAMES = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
function DayPicker({
  selected = [],
  onToggle
}) {
  return /*#__PURE__*/React.createElement("div", {
    className: "sh-daypicker"
  }, LETTERS.map((letter, i) => /*#__PURE__*/React.createElement("button", {
    key: NAMES[i],
    className: "sh-daypicker__day",
    type: "button",
    "aria-pressed": selected.includes(i) ? 'true' : 'false',
    "aria-label": NAMES[i],
    onClick: onToggle ? () => onToggle(i) : undefined
  }, letter)));
}
Object.assign(__ds_scope, { DayPicker });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/panels/DayPicker.jsx", error: String((e && e.message) || e) }); }

// components/panels/Group.jsx
try { (() => {
function Group({
  label,
  note,
  warn,
  children
}) {
  return /*#__PURE__*/React.createElement("div", {
    className: "sh-group"
  }, label ? /*#__PURE__*/React.createElement("span", {
    className: "sh-group__label"
  }, label) : null, children, note ? /*#__PURE__*/React.createElement("p", {
    className: 'sh-group__note' + (warn ? ' sh-group__note--warn' : '')
  }, note) : null);
}
Object.assign(__ds_scope, { Group });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/panels/Group.jsx", error: String((e && e.message) || e) }); }

// components/panels/HistoryRow.jsx
try { (() => {
function HistoryRow({
  week,
  meta,
  hours,
  onOpen
}) {
  return /*#__PURE__*/React.createElement("button", {
    className: "sh-histrow",
    type: "button",
    onClick: onOpen
  }, /*#__PURE__*/React.createElement("span", {
    className: "sh-histrow__main"
  }, /*#__PURE__*/React.createElement("span", {
    className: "sh-histrow__week"
  }, week), meta ? /*#__PURE__*/React.createElement("span", {
    className: "sh-histrow__meta"
  }, meta) : null), /*#__PURE__*/React.createElement("span", {
    className: "sh-histrow__hours"
  }, hours), /*#__PURE__*/React.createElement("span", {
    className: "sh-histrow__chevron"
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "chevronRight",
    size: 18
  })));
}
Object.assign(__ds_scope, { HistoryRow });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/panels/HistoryRow.jsx", error: String((e && e.message) || e) }); }

// components/panels/Panel.jsx
try { (() => {
function Panel({
  title,
  onClose,
  closeLabel = 'Close',
  actions,
  children
}) {
  return /*#__PURE__*/React.createElement("div", {
    className: "sh-panel"
  }, /*#__PURE__*/React.createElement("header", {
    className: "sh-panel__head"
  }, /*#__PURE__*/React.createElement("span", {
    className: "sh-panel__title"
  }, title), actions || /*#__PURE__*/React.createElement(__ds_scope.IconButton, {
    label: closeLabel,
    onClick: onClose
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "close",
    size: 18
  }))), /*#__PURE__*/React.createElement("div", {
    className: "sh-panel__body"
  }, children));
}
function Layer({
  open = true,
  children
}) {
  return /*#__PURE__*/React.createElement("div", {
    className: "sh-layer",
    hidden: !open
  }, children);
}
Object.assign(__ds_scope, { Panel, Layer });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/panels/Panel.jsx", error: String((e && e.message) || e) }); }

// components/panels/SettingRow.jsx
try { (() => {
function SettingRow({
  label,
  value,
  stacked,
  children
}) {
  if (stacked) {
    return /*#__PURE__*/React.createElement("div", {
      className: "sh-row sh-row--stacked"
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        gap: 'var(--sh-space-3)'
      }
    }, /*#__PURE__*/React.createElement("span", {
      className: "sh-row__label"
    }, label), value), children);
  }
  return /*#__PURE__*/React.createElement("div", {
    className: "sh-row"
  }, /*#__PURE__*/React.createElement("span", {
    className: "sh-row__label"
  }, label), value !== undefined ? typeof value === 'string' || typeof value === 'number' ? /*#__PURE__*/React.createElement("span", {
    className: "sh-row__value"
  }, value) : value : null, children);
}
function RateInput({
  currency = '€',
  value,
  placeholder = '—',
  onChange,
  label = 'Hourly rate'
}) {
  return /*#__PURE__*/React.createElement("span", {
    className: "sh-rate"
  }, /*#__PURE__*/React.createElement("span", {
    className: "sh-rate__currency"
  }, currency), /*#__PURE__*/React.createElement("input", {
    className: "sh-row__input",
    type: "text",
    inputMode: "decimal",
    placeholder: placeholder,
    "aria-label": label,
    value: value,
    onChange: onChange
  }));
}
function TypeNameInput({
  value,
  onChange,
  label = 'Week type name'
}) {
  return /*#__PURE__*/React.createElement("input", {
    className: "sh-typename",
    type: "text",
    "aria-label": label,
    value: value,
    onChange: onChange
  });
}
Object.assign(__ds_scope, { SettingRow, RateInput, TypeNameInput });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/panels/SettingRow.jsx", error: String((e && e.message) || e) }); }

// components/panels/Sheet.jsx
try { (() => {
const {
  useRef
} = React;
function Scrim({
  open = true,
  onClick
}) {
  return /*#__PURE__*/React.createElement("div", {
    className: "sh-scrim",
    hidden: !open,
    onClick: onClick
  });
}
function Sheet({
  open = true,
  title,
  label,
  onClose,
  children
}) {
  const ref = useRef(null);
  const onPointerDown = ev => {
    if (!onClose || ev.target.closest('.sh-sheet__option')) return;
    const el = ref.current;
    const y0 = ev.clientY;
    el.classList.add('is-dragging');
    const move = e => {
      el.style.transform = 'translateY(' + Math.max(0, e.clientY - y0) + 'px)';
    };
    const up = e => {
      window.removeEventListener('pointermove', move);
      window.removeEventListener('pointerup', up);
      el.classList.remove('is-dragging');
      el.classList.add('is-settling');
      if (e.clientY - y0 > 90) {
        el.style.transform = 'translateY(100%)';
        setTimeout(onClose, 240);
      } else el.style.transform = '';
    };
    window.addEventListener('pointermove', move);
    window.addEventListener('pointerup', up);
  };
  return /*#__PURE__*/React.createElement("div", {
    className: "sh-sheet",
    ref: ref,
    hidden: !open,
    role: "dialog",
    "aria-label": label,
    onPointerDown: onPointerDown
  }, /*#__PURE__*/React.createElement("div", {
    className: "sh-sheet__grip"
  }), title ? /*#__PURE__*/React.createElement("p", {
    className: "sh-sheet__title"
  }, title) : null, children);
}
function SheetOption({
  name,
  days,
  selected,
  onSelect
}) {
  return /*#__PURE__*/React.createElement("button", {
    className: "sh-sheet__option",
    type: "button",
    "aria-selected": selected ? 'true' : 'false',
    onClick: onSelect
  }, /*#__PURE__*/React.createElement("span", null, name), days ? /*#__PURE__*/React.createElement("span", {
    className: "sh-sheet__days"
  }, days) : null);
}
Object.assign(__ds_scope, { Scrim, Sheet, SheetOption });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/panels/Sheet.jsx", error: String((e && e.message) || e) }); }

// components/week/ActionBar.jsx
try { (() => {
function ActionBar({
  hint,
  children
}) {
  return /*#__PURE__*/React.createElement("footer", {
    className: "sh-actionbar"
  }, children, hint ? /*#__PURE__*/React.createElement("span", {
    className: "sh-actionbar__hint"
  }, hint) : null);
}
Object.assign(__ds_scope, { ActionBar });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/week/ActionBar.jsx", error: String((e && e.message) || e) }); }

// components/week/AppShell.jsx
try { (() => {
function AppShell({
  header,
  footer,
  children
}) {
  return /*#__PURE__*/React.createElement("div", {
    className: "sh-app"
  }, header, /*#__PURE__*/React.createElement("div", {
    className: "sh-app__body"
  }, children), footer);
}
Object.assign(__ds_scope, { AppShell });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/week/AppShell.jsx", error: String((e && e.message) || e) }); }

// components/week/BackupAlert.jsx
try { (() => {
function BackupAlert({
  title,
  note = 'Keep a copy of your hours on your phone.',
  onSave
}) {
  return /*#__PURE__*/React.createElement("div", {
    className: "sh-alert"
  }, /*#__PURE__*/React.createElement("div", {
    className: "sh-alert__text"
  }, /*#__PURE__*/React.createElement("span", {
    className: "sh-alert__title"
  }, title), /*#__PURE__*/React.createElement("span", {
    className: "sh-alert__note"
  }, note)), /*#__PURE__*/React.createElement("button", {
    className: "sh-alert__btn",
    type: "button",
    "aria-label": title,
    onClick: onSave
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "download",
    size: 20
  })));
}
Object.assign(__ds_scope, { BackupAlert });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/week/BackupAlert.jsx", error: String((e && e.message) || e) }); }

// components/week/DayRow.jsx
try { (() => {
function DayRow({
  name,
  hours,
  times,
  today,
  open,
  onOpen,
  onClear,
  clearLabel = 'Clear day',
  children
}) {
  const filled = Boolean(hours);
  return /*#__PURE__*/React.createElement("div", {
    className: 'sh-day' + (filled && !open ? ' sh-day--filled' : '') + (open ? ' sh-day--open' : '')
  }, /*#__PURE__*/React.createElement("button", {
    className: "sh-day__head",
    type: "button",
    onClick: onOpen
  }, /*#__PURE__*/React.createElement("span", {
    className: "sh-day__name"
  }, today ? /*#__PURE__*/React.createElement("span", {
    className: "sh-day__today"
  }) : null, name), filled ? /*#__PURE__*/React.createElement("span", {
    className: "sh-day__value"
  }, /*#__PURE__*/React.createElement("span", {
    className: "sh-day__hours"
  }, hours), times && !open ? /*#__PURE__*/React.createElement("span", {
    className: "sh-day__times"
  }, times) : null) : /*#__PURE__*/React.createElement("span", {
    className: "sh-day__add",
    "aria-hidden": "true"
  }, "+")), filled ? /*#__PURE__*/React.createElement("button", {
    className: "sh-day__clear",
    type: "button",
    "aria-label": clearLabel,
    onClick: onClear
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "close",
    size: 18
  })) : null, /*#__PURE__*/React.createElement("div", {
    className: "sh-day__reveal"
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "sh-day__panel"
  }, children))));
}
function DayList({
  children
}) {
  return /*#__PURE__*/React.createElement("div", {
    className: "sh-days"
  }, children);
}
Object.assign(__ds_scope, { DayRow, DayList });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/week/DayRow.jsx", error: String((e && e.message) || e) }); }

// components/week/HeroSummary.jsx
try { (() => {
const DAY_LABELS = ['M', 'T', 'W', 'T', 'F', 'S', 'S'];
function HeroSummary({
  label,
  total,
  unit = 'hrs',
  pay,
  payLabel = 'Estimated pay',
  typePill,
  week
}) {
  return /*#__PURE__*/React.createElement("section", {
    className: "sh-hero"
  }, /*#__PURE__*/React.createElement("div", {
    className: "sh-hero__top"
  }, /*#__PURE__*/React.createElement("span", {
    className: "sh-hero__label"
  }, label), typePill), /*#__PURE__*/React.createElement("div", {
    className: "sh-hero__grid"
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "sh-hero__total"
  }, total, " ", /*#__PURE__*/React.createElement("span", {
    className: "sh-hero__unit"
  }, unit)), pay ? /*#__PURE__*/React.createElement("div", {
    className: "sh-hero__meta"
  }, payLabel, " ", /*#__PURE__*/React.createElement("span", {
    className: "sh-hero__pay"
  }, pay)) : null), week ? /*#__PURE__*/React.createElement("div", {
    className: "sh-hero__week"
  }, /*#__PURE__*/React.createElement("div", {
    className: "sh-hero__bars"
  }, week.map((d, i) => /*#__PURE__*/React.createElement("i", {
    key: i,
    className: (d.on ? 'is-on ' : '') + (d.today ? 'is-today' : ''),
    style: {
      height: (d.on ? Math.max(14, d.pct ?? 60) : 12) + '%'
    }
  }))), /*#__PURE__*/React.createElement("div", {
    className: "sh-hero__barday"
  }, DAY_LABELS.map((l, i) => /*#__PURE__*/React.createElement("span", {
    key: i
  }, l)))) : null));
}
Object.assign(__ds_scope, { HeroSummary });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/week/HeroSummary.jsx", error: String((e && e.message) || e) }); }

// components/week/MessagePreview.jsx
try { (() => {
function MessagePreview({
  label = 'Message preview',
  text
}) {
  return /*#__PURE__*/React.createElement("div", {
    className: "sh-preview"
  }, /*#__PURE__*/React.createElement("span", {
    className: "sh-preview__label"
  }, label), /*#__PURE__*/React.createElement("p", {
    className: "sh-preview__bubble"
  }, text));
}
Object.assign(__ds_scope, { MessagePreview });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/week/MessagePreview.jsx", error: String((e && e.message) || e) }); }

// components/week/ScreenHeader.jsx
try { (() => {
function ScreenHeader({
  eyebrow,
  title,
  actions
}) {
  return /*#__PURE__*/React.createElement("header", {
    className: "sh-header"
  }, /*#__PURE__*/React.createElement("div", null, eyebrow ? /*#__PURE__*/React.createElement("span", {
    className: "sh-header__eyebrow"
  }, eyebrow) : null, /*#__PURE__*/React.createElement("h1", {
    className: "sh-header__title"
  }, title)), actions ? /*#__PURE__*/React.createElement("div", {
    className: "sh-header__actions"
  }, actions) : null);
}
Object.assign(__ds_scope, { ScreenHeader });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/week/ScreenHeader.jsx", error: String((e && e.message) || e) }); }

// components/week/TimeRange.jsx
try { (() => {
const STEP = 5;
function fmt(min) {
  const h = Math.floor(min / 60);
  const m = min % 60;
  return h + ':' + String(m).padStart(2, '0');
}
function duration(start, end) {
  const t = end - start;
  return Math.floor(t / 60) + '.' + String(t % 60).padStart(2, '0') + ' hrs';
}
function TimeRange({
  start = 480,
  end = 855,
  min = 360,
  max = 1200,
  onChange,
  scaleStep = 120
}) {
  const [range, setRange] = React.useState({
    start,
    end
  });
  const trackRef = React.useRef(null);
  const span = max - min;
  const pct = v => (v - min) / span * 100;
  const commit = next => {
    setRange(next);
    if ((next.start !== range.start || next.end !== range.end) && navigator.vibrate) navigator.vibrate(6);
    if (onChange) onChange(next);
  };
  const drag = which => e => {
    e.preventDefault();
    const track = trackRef.current;
    const move = ev => {
      const box = track.getBoundingClientRect();
      const x = (ev.touches ? ev.touches[0].clientX : ev.clientX) - box.left;
      const raw = min + Math.max(0, Math.min(1, x / box.width)) * span;
      const snapped = Math.round(raw / STEP) * STEP;
      commit(which === 'start' ? {
        start: Math.min(snapped, range.end - STEP),
        end: range.end
      } : {
        start: range.start,
        end: Math.max(snapped, range.start + STEP)
      });
    };
    const up = () => {
      window.removeEventListener('pointermove', move);
      window.removeEventListener('pointerup', up);
    };
    window.addEventListener('pointermove', move);
    window.addEventListener('pointerup', up);
  };
  const nudge = (which, delta) => () => commit(which === 'start' ? {
    start: Math.max(min, Math.min(range.start + delta, range.end - STEP)),
    end: range.end
  } : {
    start: range.start,
    end: Math.min(max, Math.max(range.end + delta, range.start + STEP))
  });
  const ticks = [];
  for (let v = min; v <= max; v += scaleStep) ticks.push(v);
  return /*#__PURE__*/React.createElement("div", {
    className: "sh-range"
  }, /*#__PURE__*/React.createElement("div", {
    className: "sh-range__readout"
  }, fmt(range.start), " ", /*#__PURE__*/React.createElement("span", {
    className: "sh-range__arrow"
  }, "\u2013"), " ", fmt(range.end)), /*#__PURE__*/React.createElement("div", {
    className: "sh-range__duration"
  }, duration(range.start, range.end)), /*#__PURE__*/React.createElement("div", {
    className: "sh-range__track",
    ref: trackRef
  }, /*#__PURE__*/React.createElement("div", {
    className: "sh-range__rail"
  }), /*#__PURE__*/React.createElement("div", {
    className: "sh-range__fill",
    style: {
      left: pct(range.start) + '%',
      width: pct(range.end) - pct(range.start) + '%'
    }
  }), /*#__PURE__*/React.createElement("div", {
    className: "sh-range__handle",
    style: {
      left: pct(range.start) + '%'
    },
    onPointerDown: drag('start')
  }), /*#__PURE__*/React.createElement("div", {
    className: "sh-range__handle",
    style: {
      left: pct(range.end) + '%'
    },
    onPointerDown: drag('end')
  })), /*#__PURE__*/React.createElement("div", {
    className: "sh-range__scale"
  }, ticks.map(v => /*#__PURE__*/React.createElement("span", {
    key: v,
    style: {
      left: pct(v).toFixed(2) + '%'
    }
  }, Math.floor(v / 60)))), /*#__PURE__*/React.createElement(NudgePair, {
    groups: [{
      label: 'Start',
      onMinus: nudge('start', -STEP),
      onPlus: nudge('start', STEP)
    }, {
      label: 'End',
      onMinus: nudge('end', -STEP),
      onPlus: nudge('end', STEP)
    }]
  }));
}
function NudgePair({
  groups
}) {
  return /*#__PURE__*/React.createElement("div", {
    className: "sh-nudges"
  }, groups.map(g => /*#__PURE__*/React.createElement("div", {
    className: "sh-nudge",
    key: g.label
  }, /*#__PURE__*/React.createElement("button", {
    className: "sh-nudge__btn",
    type: "button",
    "aria-label": g.label + ' earlier',
    onClick: g.onMinus
  }, "\u2212"), /*#__PURE__*/React.createElement("span", {
    className: "sh-nudge__label"
  }, g.label), /*#__PURE__*/React.createElement("button", {
    className: "sh-nudge__btn",
    type: "button",
    "aria-label": g.label + ' later',
    onClick: g.onPlus
  }, "+"))));
}
Object.assign(__ds_scope, { TimeRange, NudgePair });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/week/TimeRange.jsx", error: String((e && e.message) || e) }); }

// ui_kits/shift-hours/App.jsx
try { (() => {
const {
  Scrim,
  Sheet,
  SheetOption,
  Toast,
  Toasts,
  Button
} = window.ShiftHoursDesignSystem_074dd2;
const {
  WeekScreen,
  HistoryScreen,
  SettingsScreen
} = window;
const DATA = window.SH_DATA;
function App() {
  const [days, setDays] = React.useState(DATA.days);
  const [openDay, setOpenDay] = React.useState(null);
  const [weekEnding, setWeekEnding] = React.useState(DATA.weekEnding);
  const [pastWeek, setPastWeek] = React.useState(false);
  const [type, setType] = React.useState('Week');
  const [rate, setRate] = React.useState('');
  const [screen, setScreen] = React.useState(null);
  const [sheet, setSheet] = React.useState(null);
  const [backupDue, setBackupDue] = React.useState(true);
  const [lastBackup, setLastBackup] = React.useState(null);
  const [toasts, setToasts] = React.useState([]);
  const say = text => {
    const id = Date.now() + Math.random();
    setToasts(t => t.concat({
      id,
      text
    }));
    setTimeout(() => setToasts(t => t.filter(x => x.id !== id)), 2600);
  };
  const actions = {
    toggleDay: i => setOpenDay(o => o === i ? null : i),
    setDay: (i, r) => setDays(d => d.map((x, n) => n === i ? {
      ...x,
      start: r.start,
      end: r.end
    } : x)),
    clearDay: i => {
      setDays(d => d.map((x, n) => n === i ? {
        ...x,
        start: null,
        end: null
      } : x));
      setOpenDay(o => o === i ? null : o);
    },
    copy: text => {
      navigator.clipboard?.writeText(text).catch(() => {});
      say('Copied');
    },
    openHistory: () => setScreen('history'),
    openSettings: () => setScreen('settings'),
    openTypes: () => setSheet('types'),
    confirmClearWeek: () => setSheet('confirm'),
    backToCurrent: () => {
      setPastWeek(false);
      setWeekEnding(DATA.weekEnding);
      setDays(DATA.days);
      setOpenDay(null);
    },
    backup: () => {
      setBackupDue(false);
      setLastBackup('Last backup: August26 — 14 August');
      say('Backup saved');
    }
  };
  return /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(WeekScreen, {
    state: {
      days,
      openDay,
      weekEnding,
      type,
      rate,
      pastWeek,
      backupDue
    },
    actions: actions
  }), /*#__PURE__*/React.createElement(HistoryScreen, {
    open: screen === 'history',
    weeks: DATA.history,
    onClose: () => setScreen(null),
    onOpenWeek: wk => {
      setPastWeek(true);
      setWeekEnding(wk.week.replace('Week ending ', ''));
      setDays(DATA.days.map((d, i) => i % 2 ? {
        ...d,
        start: null,
        end: null
      } : {
        ...d,
        today: false
      }));
      setScreen(null);
      setOpenDay(null);
    }
  }), /*#__PURE__*/React.createElement(SettingsScreen, {
    open: screen === 'settings',
    rate: rate,
    types: DATA.types,
    lastBackup: lastBackup,
    onClose: () => setScreen(null),
    onRate: setRate,
    onBackup: actions.backup
  }), /*#__PURE__*/React.createElement(Scrim, {
    open: sheet !== null,
    onClick: () => setSheet(null)
  }), /*#__PURE__*/React.createElement(Sheet, {
    open: sheet === 'types',
    label: "Choose week type"
  }, DATA.types.map(t => /*#__PURE__*/React.createElement(SheetOption, {
    key: t.name,
    name: t.name,
    days: t.days,
    selected: t.name === type,
    onSelect: () => {
      setType(t.name);
      setSheet(null);
    }
  }))), /*#__PURE__*/React.createElement(Sheet, {
    open: sheet === 'confirm',
    label: "Are you sure?",
    title: (pastWeek ? 'Delete week ending ' : 'Clear week ending ') + weekEnding + '?'
  }, /*#__PURE__*/React.createElement(Button, {
    variant: "danger",
    onClick: () => {
      setDays(d => d.map(x => ({
        ...x,
        start: null,
        end: null
      })));
      setSheet(null);
      say(pastWeek ? 'Week deleted' : 'Week cleared');
    }
  }, pastWeek ? 'Delete' : 'Clear'), /*#__PURE__*/React.createElement(Button, {
    variant: "ghost",
    onClick: () => setSheet(null)
  }, "Keep it")), /*#__PURE__*/React.createElement(Toasts, null, toasts.map(t => /*#__PURE__*/React.createElement(Toast, {
    key: t.id
  }, t.text))));
}
ReactDOM.createRoot(document.getElementById('root')).render(/*#__PURE__*/React.createElement(App, null));
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/shift-hours/App.jsx", error: String((e && e.message) || e) }); }

// ui_kits/shift-hours/HistoryScreen.jsx
try { (() => {
const {
  Layer,
  Panel,
  HistoryRow,
  EmptyNote
} = window.ShiftHoursDesignSystem_074dd2;
function HistoryScreen({
  open,
  weeks,
  onClose,
  onOpenWeek
}) {
  return /*#__PURE__*/React.createElement(Layer, {
    open: open
  }, /*#__PURE__*/React.createElement(Panel, {
    title: "History",
    onClose: onClose
  }, weeks.length ? weeks.map(wk => /*#__PURE__*/React.createElement(HistoryRow, {
    key: wk.week,
    week: wk.week,
    meta: wk.meta,
    hours: wk.hours,
    onOpen: () => onOpenWeek(wk)
  })) : /*#__PURE__*/React.createElement(EmptyNote, null, "No saved weeks yet.")));
}
window.HistoryScreen = HistoryScreen;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/shift-hours/HistoryScreen.jsx", error: String((e && e.message) || e) }); }

// ui_kits/shift-hours/SettingsScreen.jsx
try { (() => {
const {
  Layer,
  Panel,
  Group,
  SettingRow,
  RateInput,
  DayPicker,
  Button,
  IconButton,
  Icon
} = window.ShiftHoursDesignSystem_074dd2;
function SettingsScreen({
  open,
  rate,
  types,
  lastBackup,
  onClose,
  onRate,
  onBackup
}) {
  const [morningDays, setMorningDays] = React.useState([0, 2, 4]);
  const toggle = i => setMorningDays(d => d.includes(i) ? d.filter(x => x !== i) : d.concat(i).sort());
  return /*#__PURE__*/React.createElement(Layer, {
    open: open
  }, /*#__PURE__*/React.createElement(Panel, {
    title: "Settings",
    onClose: onClose
  }, /*#__PURE__*/React.createElement(Group, {
    label: "Pay",
    note: "Leave it empty to hide estimated pay."
  }, /*#__PURE__*/React.createElement(SettingRow, {
    label: "Hourly rate",
    value: /*#__PURE__*/React.createElement(RateInput, {
      value: rate,
      onChange: e => onRate(e.target.value)
    })
  })), /*#__PURE__*/React.createElement(Group, {
    label: "Week types"
  }, types.slice(0, 2).map(t => /*#__PURE__*/React.createElement(SettingRow, {
    key: t.name,
    label: t.name,
    value: t.days
  })), /*#__PURE__*/React.createElement(SettingRow, {
    stacked: true,
    label: "\u2615 Mornings",
    value: /*#__PURE__*/React.createElement(IconButton, {
      plain: true,
      label: "Delete week type"
    }, /*#__PURE__*/React.createElement(Icon, {
      name: "close",
      size: 18
    }))
  }, /*#__PURE__*/React.createElement(DayPicker, {
    selected: morningDays,
    onToggle: toggle
  })), /*#__PURE__*/React.createElement(Button, {
    variant: "secondary"
  }, "Add week type")), /*#__PURE__*/React.createElement(Group, {
    label: "Your hours",
    note: lastBackup || 'No backup yet',
    warn: !lastBackup
  }, /*#__PURE__*/React.createElement(Button, {
    variant: "secondary",
    onClick: onBackup
  }, "Download backup"), /*#__PURE__*/React.createElement(Button, {
    variant: "secondary"
  }, "Restore from backup"))));
}
window.SettingsScreen = SettingsScreen;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/shift-hours/SettingsScreen.jsx", error: String((e && e.message) || e) }); }

// ui_kits/shift-hours/WeekScreen.jsx
try { (() => {
const {
  AppShell,
  ScreenHeader,
  ActionBar,
  HeroSummary,
  TypePill,
  DayList,
  DayRow,
  TimeRange,
  BackupAlert,
  MessagePreview,
  Button,
  IconButton,
  Icon,
  Chip
} = window.ShiftHoursDesignSystem_074dd2;
const F = window.SH_FMT;
function WeekScreen({
  state,
  actions
}) {
  const {
    days,
    openDay,
    weekEnding,
    type,
    rate,
    pastWeek,
    backupDue
  } = state;
  const worked = days.filter(d => d.start != null);
  const totalMin = worked.reduce((n, d) => n + (d.end - d.start), 0);
  const pay = rate ? (totalMin / 60 * Number(rate)).toFixed(2) + '€' : null;
  const summary = ['Week ending ' + weekEnding].concat(worked.map(d => d.name + ': ' + F.clock(d.start) + ' - ' + F.clock(d.end) + ' ' + F.hours(d.end - d.start) + ' hrs')).concat([F.words(totalMin)]).join('\n');
  return /*#__PURE__*/React.createElement(AppShell, {
    header: /*#__PURE__*/React.createElement(ScreenHeader, {
      eyebrow: "Week ending",
      title: weekEnding,
      actions: /*#__PURE__*/React.createElement(React.Fragment, null, pastWeek ? /*#__PURE__*/React.createElement(Chip, {
        onClick: actions.backToCurrent
      }, /*#__PURE__*/React.createElement(Icon, {
        name: "chevronLeft",
        size: 14
      }), " This week") : null, /*#__PURE__*/React.createElement(IconButton, {
        label: "History",
        onClick: actions.openHistory
      }, /*#__PURE__*/React.createElement(Icon, {
        name: "history",
        size: 21
      })), /*#__PURE__*/React.createElement(IconButton, {
        label: "Settings",
        onClick: actions.openSettings
      }, /*#__PURE__*/React.createElement(Icon, {
        name: "settings",
        size: 21
      })))
    }),
    footer: /*#__PURE__*/React.createElement(ActionBar, null, /*#__PURE__*/React.createElement(Button, {
      disabled: !worked.length,
      onClick: () => actions.copy(summary)
    }, "Copy summary"))
  }, /*#__PURE__*/React.createElement(HeroSummary, {
    label: pastWeek ? 'Saved week' : 'This week',
    total: F.hours(totalMin),
    pay: pay,
    typePill: /*#__PURE__*/React.createElement(TypePill, {
      name: type,
      onClick: actions.openTypes
    })
  }), /*#__PURE__*/React.createElement(DayList, null, days.map((d, i) => /*#__PURE__*/React.createElement(DayRow, {
    key: d.name,
    name: d.name,
    today: d.today,
    hours: d.start != null ? F.hours(d.end - d.start) + ' hrs' : undefined,
    times: d.start != null ? F.clock(d.start) + ' – ' + F.clock(d.end) : undefined,
    open: openDay === i,
    onOpen: () => actions.toggleDay(i),
    onClear: () => actions.clearDay(i),
    clearLabel: 'Clear ' + d.name
  }, /*#__PURE__*/React.createElement(TimeRange, {
    key: 'r' + i,
    start: d.start ?? 480,
    end: d.end ?? 960,
    onChange: r => actions.setDay(i, r)
  })))), backupDue ? /*#__PURE__*/React.createElement(BackupAlert, {
    title: "Back up August",
    onSave: actions.backup
  }) : null, worked.length ? /*#__PURE__*/React.createElement(MessagePreview, {
    text: summary
  }) : null, worked.length ? /*#__PURE__*/React.createElement("div", {
    className: "sh-group"
  }, /*#__PURE__*/React.createElement(Button, {
    variant: "danger",
    onClick: actions.confirmClearWeek
  }, pastWeek ? 'Delete week' : 'Clear week')) : null);
}
window.WeekScreen = WeekScreen;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/shift-hours/WeekScreen.jsx", error: String((e && e.message) || e) }); }

// ui_kits/shift-hours/data.js
try { (() => {
/* Dati d'esempio interamente inventati: nel repo non entra mai un orario reale. */
window.SH_DATA = {
  weekEnding: '16 August',
  days: [{
    name: 'Monday',
    start: 480,
    end: 990
  }, {
    name: 'Tuesday',
    start: null,
    end: null
  }, {
    name: 'Wednesday',
    start: 480,
    end: 855
  }, {
    name: 'Thursday',
    start: 540,
    end: 1045,
    today: true
  }, {
    name: 'Friday',
    start: null,
    end: null
  }, {
    name: 'Saturday',
    start: 510,
    end: 1020
  }, {
    name: 'Sunday',
    start: null,
    end: null
  }],
  history: [{
    week: 'Week ending 9 August',
    meta: '2026 · 5 days',
    hours: '38.15'
  }, {
    week: 'Week ending 2 August',
    meta: '2026 · 5 days',
    hours: '41.00'
  }, {
    week: 'Week ending 26 July',
    meta: '2026 · 2 days',
    hours: '15.00'
  }, {
    week: 'Week ending 19 July',
    meta: '2026 · 4 days',
    hours: '35.30'
  }, {
    week: 'Week ending 12 July',
    meta: '2026 · 5 days',
    hours: '47.00'
  }],
  types: [{
    name: 'Week',
    days: 'Mon – Sun'
  }, {
    name: 'Weekend',
    days: 'Sat – Sun'
  }, {
    name: '☕ Mornings',
    days: 'Mon · Wed · Fri'
  }]
};
window.SH_FMT = {
  clock(min) {
    return Math.floor(min / 60) + ':' + String(min % 60).padStart(2, '0');
  },
  hours(min) {
    return Math.floor(min / 60) + '.' + String(min % 60).padStart(2, '0');
  },
  words(min) {
    return Math.floor(min / 60) + ' hours and ' + min % 60 + ' minutes';
  }
};
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/shift-hours/data.js", error: String((e && e.message) || e) }); }

__ds_ns.Button = __ds_scope.Button;

__ds_ns.Chip = __ds_scope.Chip;

__ds_ns.EmptyNote = __ds_scope.EmptyNote;

__ds_ns.Icon = __ds_scope.Icon;

__ds_ns.IconButton = __ds_scope.IconButton;

__ds_ns.Toast = __ds_scope.Toast;

__ds_ns.Toasts = __ds_scope.Toasts;

__ds_ns.TypePill = __ds_scope.TypePill;

__ds_ns.DayPicker = __ds_scope.DayPicker;

__ds_ns.Group = __ds_scope.Group;

__ds_ns.HistoryRow = __ds_scope.HistoryRow;

__ds_ns.Panel = __ds_scope.Panel;

__ds_ns.Layer = __ds_scope.Layer;

__ds_ns.SettingRow = __ds_scope.SettingRow;

__ds_ns.RateInput = __ds_scope.RateInput;

__ds_ns.TypeNameInput = __ds_scope.TypeNameInput;

__ds_ns.Scrim = __ds_scope.Scrim;

__ds_ns.Sheet = __ds_scope.Sheet;

__ds_ns.SheetOption = __ds_scope.SheetOption;

__ds_ns.ActionBar = __ds_scope.ActionBar;

__ds_ns.AppShell = __ds_scope.AppShell;

__ds_ns.BackupAlert = __ds_scope.BackupAlert;

__ds_ns.DayRow = __ds_scope.DayRow;

__ds_ns.DayList = __ds_scope.DayList;

__ds_ns.HeroSummary = __ds_scope.HeroSummary;

__ds_ns.MessagePreview = __ds_scope.MessagePreview;

__ds_ns.ScreenHeader = __ds_scope.ScreenHeader;

__ds_ns.TimeRange = __ds_scope.TimeRange;

__ds_ns.NudgePair = __ds_scope.NudgePair;

})();
